package com.leongrill.nics.leongrill.Menu.Adapter;


import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.leongrill.nics.leongrill.Menu.Dto.ItemObject;
import com.leongrill.nics.leongrill.R;

import java.util.ArrayList;

/**
 * Created by Savithri on 13-06-2017.
 */
public class YourOrderDetailsItemAdapter extends RecyclerView.Adapter<YourOrderDetailsItemAdapter.MyViewHolder>{
    private Context context;
    private ArrayList<ItemObject> list;
    private LayoutInflater layoutInflater;
    public YourOrderDetailsItemAdapter(Context context, ArrayList<ItemObject> list) {
        this.context = context;
        this.list = list;
        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view=layoutInflater.inflate(R.layout.content_oderdetails_card_view,parent,false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        ItemObject item=list.get(position);
        holder.name_tv.setText(item.getItemName());
        float totalprice=Float.parseFloat(item.getPrice());
        int q=Integer.parseInt(item.getQuantity());
        holder.amount_tv.setText(""+totalprice*q);
        holder.price_tv.setText(item.getPrice());
        holder.quantity_tv.setText(item.getQuantity());


    }


    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView name_tv;
        private TextView price_tv;
        private TextView amount_tv;
        private TextView quantity_tv;

        public MyViewHolder(View itemView) {
            super(itemView);
            name_tv = (TextView)itemView.findViewById(R.id.orderDetailsItemName);
            quantity_tv = (TextView)itemView.findViewById(R.id.orderDetailsQuantity);
            price_tv = (TextView)itemView.findViewById(R.id.orderDetailsPrice);
            amount_tv = (TextView)itemView.findViewById(R.id.orderDetailsAmount);

        }
    }
}
