package com.leongrill.nics.leongrill.Menu;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.leongrill.nics.leongrill.Drawer.MainActivity;
import com.leongrill.nics.leongrill.Menu.Fragment.ItemFragment;
import com.leongrill.nics.leongrill.Menu.Fragment.MenuItemFragment;
import com.leongrill.nics.leongrill.R;
import com.leongrill.nics.leongrill.Utils.BadgeDrawable;
import com.leongrill.nics.leongrill.Utils.IFragmentCommunicator;

import java.util.HashMap;
import java.util.Map;

public class MenuActivity extends AppCompatActivity implements IFragmentCommunicator {

    TabLayout tabLayout;
    private Button review_btn;
    SharedPreferences sharedPreferences;
    Bundle bundle ;
    LayerDrawable mCartMenuIcon;
    int count;
    Fragment fragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        getSupportActionBar().setTitle("Menu Available");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        tabLayout=(TabLayout)findViewById(R.id.menu_tab_layout);
        bindWidgetsWithAnEvent();
        setupTabLayout();
        review_btn=(Button)findViewById(R.id.veg_review_button);
        bundle = new Bundle();
        review_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmentCommunication();

            }
        });

    }
    private void setupTabLayout() {


        tabLayout.addTab(tabLayout.newTab().setText("Veg"),true);
        tabLayout.addTab(tabLayout.newTab().setText("NonVeg"));
        tabLayout.addTab(tabLayout.newTab().setText("Dessert"));
    }
    private void bindWidgetsWithAnEvent()
    {
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                setCurrentTabFragment(tab.getPosition());
            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });
    }


    private void setCurrentTabFragment(int tabPosition)
    {
            switch (tabPosition)
            {
                case 0 :
                    replaceFragment(0,"veg");
                    break;
                case 1 :
                     replaceFragment(1,"nonVeg");
                break;
                case 2 :
                    replaceFragment(2,"dessert");
                    break;
            }
    }
    public void replaceFragment(int i, String name) {
        fragment=new ItemFragment().newInstance(i,name);
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.frame_container, fragment);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        ft.commit();
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.order_menu, menu);
        mCartMenuIcon = (LayerDrawable) menu.findItem(R.id.action_cart).getIcon();
        setBadgeCount(this, mCartMenuIcon, count+"");
        return true;
    }

    public static void setBadgeCount(Context context, LayerDrawable icon, String count) {

        BadgeDrawable badge;

        // Reuse drawable if possible
        Drawable reuse = icon.findDrawableByLayerId(R.id.ic_badge);
        if (reuse != null && reuse instanceof BadgeDrawable) {
            badge = (BadgeDrawable) reuse;
        } else {
            badge = new BadgeDrawable(context);
        }

        badge.setCount(count);
        icon.mutate();
        icon.setDrawableByLayerId(R.id.ic_badge, badge);
    }

   @Override
   public void onResume() {
       super.onResume();
       sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
       count = sharedPreferences.getInt("itemcount", 0);
       if (count != 0 && mCartMenuIcon!=null) {
           if (count<10)
               setBadgeCount(MenuActivity.this, mCartMenuIcon, ""+count);
           else
               setBadgeCount(MenuActivity.this, mCartMenuIcon, count+"");
       }
   }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case android.R.id.home:
                onBackPressed();
                break;
            case R.id.action_cart:
                fragmentCommunication();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {

        Intent i = new Intent(MenuActivity.this, MainActivity.class);
        startActivity(i);
        finish();
    }

    @Override
    public void fragmentCommunication() {
        Intent continueIntent=new Intent(MenuActivity.this,YourOrderDetailsActivity.class);
        startActivity(continueIntent);
    }


}
