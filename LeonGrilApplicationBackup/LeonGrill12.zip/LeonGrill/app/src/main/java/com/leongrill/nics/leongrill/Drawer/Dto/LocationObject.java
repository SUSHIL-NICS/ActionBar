package com.leongrill.nics.leongrill.Drawer.Dto;

/**
 * Created by Savithri on 26-06-2017.
 */

public class LocationObject {
    private String latitude;
    private String longitude;
    private String area;
    public LocationObject(String latitude,String longitude,String area)
    {
        this.latitude=latitude;
        this.longitude=longitude;
        this.area=area;
    }


    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }



}
