package com.leongrill.nics.leongrill.Drawer.Dto;

/**
 * Created by sushil on 02-06-2017.
 */
public class MyOrderItemObject {
    private String store;
    private String product;
    private String quantity;
    private int image;


    public MyOrderItemObject(int image, String store, String quantity, String product) {
        this.store = store;
        this.product = product;
        this.quantity = quantity;
        this.image=image;
    }

    public String getStore() {
        return store;
    }

    public void setStore(String store) {
        this.store = store;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}


