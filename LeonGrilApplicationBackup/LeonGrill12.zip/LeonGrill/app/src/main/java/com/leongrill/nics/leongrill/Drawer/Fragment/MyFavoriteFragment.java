package com.leongrill.nics.leongrill.Drawer.Fragment;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.leongrill.nics.leongrill.Database.DatabaseHelper;
import com.leongrill.nics.leongrill.Drawer.Adapter.FavoriteItemAdapter;
import com.leongrill.nics.leongrill.Drawer.Dto.FavoriteItemObject;

import com.leongrill.nics.leongrill.Drawer.FragmentCommunicator;
import com.leongrill.nics.leongrill.Menu.Adapter.YourOrderDetailsItemAdapter;
import com.leongrill.nics.leongrill.Menu.Dto.ItemObject;
import com.leongrill.nics.leongrill.Menu.RecyclerItemClickListener;
import com.leongrill.nics.leongrill.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Subrat on 13-06-2017.
 */

public class MyFavoriteFragment extends Fragment {

    private RecyclerView recyclerView;
    private DatabaseHelper helper;
    private ArrayList<ItemObject> items;
    private LinearLayout cartLinear;
    private int positions;
    private AppCompatButton favorite_btn;
    FavoriteItemAdapter favoriteItemAdapter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_favorite,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView=(RecyclerView)view.findViewById(R.id.my_favorite_RecyclerView);
        helper=new DatabaseHelper(getContext());

        cartLinear= (LinearLayout)view.findViewById(R.id.cart_liner);
        favorite_btn= (AppCompatButton)view.findViewById(R.id.favorite_bt);
        favorite_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentCommunicator communicator= (FragmentCommunicator) getActivity();
                communicator.fragmentCommunication();
            }
        });
        items=helper.getCartItemFavorite();
        if(items.size()==0){
            cartLinear.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.INVISIBLE);
        }
         recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
         favoriteItemAdapter=new FavoriteItemAdapter(getContext(),items);
         recyclerView.setAdapter(favoriteItemAdapter);
         recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getContext(),new RecyclerItemClickListener.OnItemClickListener() {
                    int count=0;
                    @Override
                    public void onItemClick(final View view, final int position) {
                        final ItemObject item=items.get(position);
                        positions=position;

                        ImageButton delete=(ImageButton) view.findViewById(R.id.favorite_productDelete_button);
                        ImageButton cart=(ImageButton) view.findViewById(R.id.favorite_cart_button);

                        delete.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                helper.updateFavorite(item.getItemName(), "0");
                                items.remove(position);
                                favoriteItemAdapter.notifyDataSetChanged();
                                if(items.size()==0) {
                                    cartLinear.setVisibility(View.VISIBLE);
                                    recyclerView.setVisibility(View.INVISIBLE);
                                }
                            }
                        });

                        cart.setOnClickListener(new View.OnClickListener() {
                            int c =0;
                            @Override
                            public void onClick(View v) {
                                String s=helper.fetchFromCartItemQuantity(item.getItemName());
                                if (s!=null && !s.equalsIgnoreCase("0")){

                                    Snackbar snackbar = Snackbar.make(view.findViewById(R.id.favorite_productDelete_button),
                                            " Item already has been Bagged .", Snackbar.LENGTH_LONG);
                                    View sbView = snackbar.getView();
                                    TextView textView = (TextView) sbView.findViewById(android.support.design.R.id.snackbar_text);
                                    textView.setTextColor(Color.RED);
                                    snackbar.show();

                                }else {
                                    if(item.getQuantity()==null) {
                                        ++c;
                                        item.setQuantity(c + "");
                                        helper.updateCart(item.getItemName(), item.getQuantity());
                                        Snackbar snackbar = Snackbar.make(view.findViewById(R.id.favorite_productDelete_button),
                                                " Your Item  has Successfully added.", Snackbar.LENGTH_LONG);
                                        View sbView = snackbar.getView();
                                        TextView textView = (TextView) sbView.findViewById(android.support.design.R.id.snackbar_text);
                                        textView.setTextColor(Color.YELLOW);
                                        snackbar.show();
                                    }else{
                                        c=Integer.parseInt(item.getQuantity());
                                        if(c==0){
                                            ++c;
                                            item.setQuantity(c+"");
                                            helper.updateCart(item.getItemName(), item.getQuantity());
                                            Snackbar snackbar = Snackbar.make(view.findViewById(R.id.favorite_productDelete_button),
                                                    " Your Item  has Successfully added.", Snackbar.LENGTH_LONG);
                                            View sbView = snackbar.getView();
                                            TextView textView = (TextView) sbView.findViewById(android.support.design.R.id.snackbar_text);
                                            textView.setTextColor(Color.YELLOW);
                                            snackbar.show();
                                        }
                                        else {

                                            Snackbar snackbar = Snackbar.make(view.findViewById(R.id.favorite_productDelete_button),
                                                    " Item already has been Bagged .", Snackbar.LENGTH_LONG);
                                            View sbView = snackbar.getView();
                                            TextView textView = (TextView) sbView.findViewById(android.support.design.R.id.snackbar_text);
                                            textView.setTextColor(Color.RED);
                                            snackbar.show();
                                        }
                                    }
                                }

                            }
                        });


                    }
                }));
    }
    @Override
    public void onResume() {
        super.onResume();
        if(items.size()==0){
            cartLinear.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.INVISIBLE);
            //sendmail.setVisibility(View.INVISIBLE);

        }
    }

    @Override
    public void onPause() {
        super.onPause();
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        SharedPreferences.Editor editor = sharedPreferences.edit();
        items=helper.getCartItem();
        if(items.size() !=0) {
            int count=items.size();
            editor.putInt("itemcount", count);
            editor.apply();
        }

    }

}
