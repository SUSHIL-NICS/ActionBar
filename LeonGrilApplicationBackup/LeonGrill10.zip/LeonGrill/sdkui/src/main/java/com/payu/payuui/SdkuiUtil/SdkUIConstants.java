package com.payu.payuui.SdkuiUtil;

/**
 * Created by harmeet on 13/8/15.
 */
public interface SdkUIConstants {

    String SAVED_CARDS = "Saved Cards";
    String CREDIT_DEBIT_CARDS = "Credit/Debit Cards";
    String NET_BANKING = "Net Banking";

    String CASH_CARDS = "Cash Cards";
    String EMI = "EMI";

    String AMOUNT = "Amount";
    String TXN_ID = "Txnid";
    String VALUE_ADDED = "Value Added Services";
    String ISSUING_BANK_STATUS = "Issuing Bank Status";
    String POSITION = "Position";

    String MAESTRO = "MAESTRO";

    String CREDIT_CARDS = "Credit Cards";
    String DEBIT_CARDS = "Debit Cards";
}