package com.leongrill.nics.leongrill.Menu.Fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.leongrill.nics.leongrill.Menu.Adapter.DessertItemAdapter;
import com.leongrill.nics.leongrill.Menu.Adapter.NonVegItemAdapter;
import com.leongrill.nics.leongrill.Menu.Dto.NonVegItemObject;
import com.leongrill.nics.leongrill.R;

import java.util.ArrayList;
import java.util.List;


public class DessertFragment extends Fragment {

    private RecyclerView recyclerView;

    public DessertFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_veg, container, false);
    }
    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView=(RecyclerView)view.findViewById(R.id.veg_RecyclerView);
        List<NonVegItemObject> list=getAllMileStoneObject();
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        StaggeredGridLayoutManager staggeredGridLayoutManager=new StaggeredGridLayoutManager(2,StaggeredGridLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(staggeredGridLayoutManager);
        DessertItemAdapter nonVegItemAdapter=new DessertItemAdapter(getContext(),list);
        recyclerView.setAdapter(nonVegItemAdapter);
//        recyclerView.setNestedScrollingEnabled(false);
    }
    public List<NonVegItemObject> getAllMileStoneObject(){
        List<NonVegItemObject> mList=new ArrayList<>();
        mList.add(new NonVegItemObject(R.drawable.burger_combo,"Chicken Burger Combo"," 150.00"));

        mList.add(new NonVegItemObject(R.drawable.doner_combo," Donner Combo"," 250.00"));

        mList.add(new NonVegItemObject(R.drawable.falafal_doner_salad," Chicken Falafal Donner Salad "," 120.00"));

        mList.add(new NonVegItemObject(R.drawable.paneer_peri_peri_wrap," Pannier Peri Peri Wrap","140.00"));

        mList.add(new NonVegItemObject(R.drawable.peri_peri_paneer_salad," Chicken Peri Peri Pannier Salad " ,"150.00"));

        mList.add(new NonVegItemObject(R.drawable.vegburger,"Chicken  Vegeburger ","80.00"));

        mList.add(new NonVegItemObject(R.drawable.burger_combo," Chicken Burger Combo"," 150.00"));

        mList.add(new NonVegItemObject(R.drawable.doner_combo," Donner Combo"," 250.00"));

        mList.add(new NonVegItemObject(R.drawable.falafal_doner_salad,"Chicken  Falafal Donner Salad "," 120.00"));

        mList.add(new NonVegItemObject(R.drawable.paneer_peri_peri_wrap," Pannier Peri Peri Wrap","140.00"));

        mList.add(new NonVegItemObject(R.drawable.peri_peri_paneer_salad," Peri Peri Pannier Salad " ,"150.00"));

        mList.add(new NonVegItemObject(R.drawable.vegburger,"Chicken  Vegeburger ","80.00"));

        return mList;

    }

}
