package com.leongrill.nics.leongrill.Menu.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.leongrill.nics.leongrill.Menu.Dto.NonVegItemObject;
import com.leongrill.nics.leongrill.Menu.Dto.VegItemObject;
import com.leongrill.nics.leongrill.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Savithri on 12-06-2017.
 */

public class NonVegItemAdapter extends RecyclerView.Adapter<NonVegItemAdapter.MyViewHolder>{
    private Context context;
    private ArrayList<VegItemObject> list;
    private LayoutInflater layoutInflater;
    public NonVegItemAdapter(Context context, ArrayList<VegItemObject> list) {
        this.context=context;
        this.list = list;
        layoutInflater = LayoutInflater.from(context);
    }



    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view =layoutInflater.inflate(R.layout.containt_veg_menu_fragment,parent,false);
        MyViewHolder myViewHolder =  new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        VegItemObject vegItemObject=list.get(position);
        holder.name_tv.setText(vegItemObject.getItemName());
        holder.price_tv.setText(vegItemObject.getPrice());
        holder.background_imv.setImageResource(vegItemObject.getImage());
        if(vegItemObject.getQuantity()!=null && !vegItemObject.getQuantity().equalsIgnoreCase("0")){

        }

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView name_tv;
        private TextView price_tv;
        private ImageView background_imv;
        private ImageButton addToCard_imb;
        private ImageButton fav_imb;

        public MyViewHolder(View itemView) {
            super(itemView);
            name_tv = (TextView)itemView.findViewById(R.id.veg_name_textView);
            price_tv = (TextView)itemView.findViewById(R.id.veg_price_textView);
            background_imv = (ImageView) itemView.findViewById(R.id.veg_imageView);
            addToCard_imb = (ImageButton) itemView.findViewById(R.id.veg_add_to_card_imageButton);
            fav_imb = (ImageButton) itemView.findViewById(R.id.veg_favorite_imageButton);
        }
    }
}
