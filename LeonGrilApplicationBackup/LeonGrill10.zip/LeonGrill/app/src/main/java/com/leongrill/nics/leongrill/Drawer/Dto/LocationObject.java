package com.leongrill.nics.leongrill.Drawer.Dto;

/**
 * Created by sushil on 23-06-2017.
 */
public class LocationObject {
    private String lat;

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    private String lng;
    private String area;

    public LocationObject(String lat,String lng,String area)
    {
        this.lat=lat;
        this.lng=lng;
        this.area=area;
    }

}
