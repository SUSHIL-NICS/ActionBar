package com.leongrill.nics.leongrill.Drawer.Fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.leongrill.nics.leongrill.Drawer.Adapter.FavoriteItemAdapter;
import com.leongrill.nics.leongrill.Drawer.Dto.FavoriteItemObject;

import com.leongrill.nics.leongrill.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Savithri on 13-06-2017.
 */

public class MyFavoriteFragment extends Fragment {

    private RecyclerView recyclerView;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_favorite,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView=(RecyclerView)view.findViewById(R.id.my_favorite_RecyclerView);
        List<FavoriteItemObject> list=getAllMileStoneObject();
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        FavoriteItemAdapter favoriteItemAdapter=new FavoriteItemAdapter(getContext(),list);
        recyclerView.setAdapter(favoriteItemAdapter);
    }
    public List<FavoriteItemObject> getAllMileStoneObject(){
        List<FavoriteItemObject> mList=new ArrayList<>();
        mList.add(new FavoriteItemObject(R.drawable.burger_combo,"Burger Combo"," 150.00"));

        mList.add(new FavoriteItemObject(R.drawable.doner_combo,"Donner Combo"," 250.00"));

        mList.add(new FavoriteItemObject(R.drawable.falafal_doner_salad," Falafal Donner Salad "," 120.00"));

        mList.add(new FavoriteItemObject(R.drawable.paneer_peri_peri_wrap,"Pannier Peri Peri Wrap","140.00"));

        mList.add(new FavoriteItemObject(R.drawable.peri_peri_paneer_salad," Peri Peri Pannier Salad " ,"150.00"));

        mList.add(new FavoriteItemObject(R.drawable.vegburger," Vegeburger ","80.00"));

        mList.add(new FavoriteItemObject(R.drawable.burger_combo,"Burger Combo"," 150.00"));

        mList.add(new FavoriteItemObject(R.drawable.doner_combo,"Donner Combo"," 250.00"));

        mList.add(new FavoriteItemObject(R.drawable.falafal_doner_salad," Falafal Donner Salad "," 120.00"));

        mList.add(new FavoriteItemObject(R.drawable.paneer_peri_peri_wrap,"Pannier Peri Peri Wrap","140.00"));

        mList.add(new FavoriteItemObject(R.drawable.peri_peri_paneer_salad," Peri Peri Pannier Salad " ,"150.00"));

        mList.add(new FavoriteItemObject(R.drawable.vegburger," Vegeburger ","80.00"));

        return mList;

    }
}
