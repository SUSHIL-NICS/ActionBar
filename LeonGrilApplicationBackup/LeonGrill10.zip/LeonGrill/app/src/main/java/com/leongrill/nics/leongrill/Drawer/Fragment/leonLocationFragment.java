package com.leongrill.nics.leongrill.Drawer.Fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;


import com.leongrill.nics.leongrill.Database.DatabaseHelper;
import com.leongrill.nics.leongrill.Drawer.Dto.LocationObject;
import com.leongrill.nics.leongrill.Drawer.FragmentCommunicator;
import com.leongrill.nics.leongrill.R;

import java.util.ArrayList;
import java.util.List;


public class leonLocationFragment extends Fragment {

    private Fragment fragment;
    private FragmentManager fragmentManager;


    private List<LocationObject> list;
    private DatabaseHelper helper;
    RadioButton radioButton1;
    RadioButton radioButton2;
    RadioButton radioButton3;
    RadioButton radioButton4;
    RadioGroup radioGroup;
    Button findLeno_btn;
    LocationObject LocationObject;
    Button button;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        CopyData data=null;

        helper=new DatabaseHelper(getActivity());
        final int itemcount=helper.getLocationItemCount();
        if (itemcount==0){
            data = new CopyData();
            data.execute();
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_leon_location, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        radioButton1=(RadioButton)view.findViewById(R.id.location_radio_button_one);
        findLeno_btn=(Button)view.findViewById(R.id.findLeno_btn);
        radioButton2=(RadioButton)view.findViewById(R.id.location_radio_button_two);
        radioButton3=(RadioButton)view.findViewById(R.id.location_radio_button_three);
        radioButton4=(RadioButton)view.findViewById(R.id.location_radio_button_four);
        radioGroup=(RadioGroup)view.findViewById(R.id.leon_location_radio_group);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId==R.id.location_radio_button_one){
                    LocationObject=helper.getLocationData("HSR");
                }else if (checkedId==R.id.location_radio_button_two){
                    LocationObject=helper.getLocationData("JeevanBimaHAL");
                }else if (checkedId==R.id.location_radio_button_three){
                    LocationObject=helper.getLocationData("JeevanBimaComplex");
                }else if (checkedId==R.id.location_radio_button_four){
                    LocationObject=helper.getLocationData("IndraNagar");
                }
            }
        });

        findLeno_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int checkedId =radioGroup.getCheckedRadioButtonId();
                if (checkedId==R.id.location_radio_button_one){
                  /*  HomeFragment homeFragment=new HomeFragment();
                    Bundle args = new Bundle();
                    args.putString("x", LocationObject.getLat() + LocationObject.getLng());
                    homeFragment.setArguments(args);
                   getFragmentManager().beginTransaction().add(R.id.main_frame, homeFragment).commit();*/
                    Toast.makeText(getContext(),LocationObject.getLat()+"   HSR----- "+LocationObject.getLng(),Toast.LENGTH_LONG).show();

                    sendData(LocationObject.getLat(),LocationObject.getLng());
                }else if (checkedId==R.id.location_radio_button_two){
                    Toast.makeText(getContext(),LocationObject.getLat()+"   BIMA HAL----- "+LocationObject.getLng(),Toast.LENGTH_LONG).show();
                    sendData(LocationObject.getLat(),LocationObject.getLng());
                }else if (checkedId==R.id.location_radio_button_three){
                    Toast.makeText(getContext(),LocationObject.getLat()+"  Complex ----- "+LocationObject.getLng(),Toast.LENGTH_LONG).show();
                    sendData(LocationObject.getLat(),LocationObject.getLng());
                }else if (checkedId==R.id.location_radio_button_four){
                    Toast.makeText(getContext(),LocationObject.getLat()+"   In----- "+LocationObject.getLng(),Toast.LENGTH_LONG).show();
                    sendData(LocationObject.getLat(),LocationObject.getLng());
                }
            }
        });




    }

    public  void sendData(String lat,String lng)
    {
        FragmentCommunicator communicator= (FragmentCommunicator) getActivity();
        communicator.fragmentCommunicationLocation(lat,lng);
    }
    private class CopyData  extends AsyncTask<String,Void,Void> {

        private ProgressDialog progressDialog;

        @Override
        protected Void doInBackground(String... params) {
            list = getLocation();
            for(LocationObject item:list)
                helper.insertLocation(item);
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //Showing progress dialog while sending email
            progressDialog = ProgressDialog.show(getContext(),"","Please wait...",false,false);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            //Dismissing the progress dialog
            progressDialog.dismiss();
        }
    }

    private List<LocationObject> getLocation() {
        ArrayList<LocationObject> mList=new ArrayList<>();

        //category veg item
        mList.add(new LocationObject("12.911761","77.643799","HSR"));

        mList.add(new LocationObject("12.969132","77.648869","JeevanBimaHAL"));

        mList.add(new LocationObject("12.966578","77.660794","JeevanBimaComplex"));

        mList.add(new LocationObject("12.979231","77.640627","IndraNagar"));
        return mList;
    }


    
}
