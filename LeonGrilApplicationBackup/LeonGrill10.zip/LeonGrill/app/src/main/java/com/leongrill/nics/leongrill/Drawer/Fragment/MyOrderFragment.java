package com.leongrill.nics.leongrill.Drawer.Fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.leongrill.nics.leongrill.Drawer.Adapter.MyOrderAdapter;
import com.leongrill.nics.leongrill.Drawer.Dto.MyOrderItemObject;
import com.leongrill.nics.leongrill.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Savithri on 13-06-2017.
 */

public class MyOrderFragment extends Fragment {
    MyOrderAdapter myOrderAdapter;
    private RecyclerView my_order_RecyclerView;


    public List<MyOrderItemObject> listItem=new ArrayList<>();
    String[] delivary_date={"Wednesday,01/12/2017","Friday,23/12/2016","Tuesday,14/02/2017","Wednesday,01/12/2017","Friday,31/12/2017","saturdayday,01/09/2017"};
    String[] quantity={"9","7","6","1","3","2"};
    String[] product={"Chicken Burger Combo","Chicken Donner Combo","chicken Pannier Peri Peri Wrap","chicken Pannier Peri Peri Wrap","Chicken  Vegeburger ","Chicken  Falafal Donner Salad "};
    private static final int[] IMAGES= {R.drawable.burger_combo,R.drawable.chinken_fillet,R.drawable.doner_combo,R.drawable.falafal_doner_salad,R.drawable.paneer_peri_peri_wrap,R.drawable.peri_peri_paneer_salad};
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_order,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        my_order_RecyclerView = (RecyclerView) view.findViewById(R.id.my_order_RecyclerView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        my_order_RecyclerView.setLayoutManager(layoutManager);
        /*for (String s:medicine){
            listItem.add(new ListItem(s));
        }*/

        for (int i = 0; i <= quantity.length - 1; i++) {
            MyOrderItemObject list = new MyOrderItemObject(IMAGES[i],product[i], quantity[i],delivary_date[i]);
            listItem.add(list);
        }
        myOrderAdapter = new MyOrderAdapter(listItem, getContext());

        my_order_RecyclerView.setAdapter(myOrderAdapter);

    }
}
