package com.leongrill.nics.leongrill.Drawer;

import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

import com.leongrill.nics.leongrill.Drawer.Fragment.HomeFragment;
import com.leongrill.nics.leongrill.Drawer.Fragment.MyFavoriteFragment;
import com.leongrill.nics.leongrill.Drawer.Fragment.MyOrderFragment;
import com.leongrill.nics.leongrill.Drawer.Fragment.OffersFragment;
import com.leongrill.nics.leongrill.Drawer.Fragment.SettingsFragment;
import com.leongrill.nics.leongrill.Drawer.Fragment.leonLocationFragment;
import com.leongrill.nics.leongrill.R;

public class MainActivity extends AppCompatActivity
    implements NavigationView.OnNavigationItemSelectedListener,FragmentCommunicator {

    private Fragment fragment;
    private FragmentManager fragmentManager;
    private static final int PERMISSION_REQUEST_CODE = 200;
    private String FINE_LOCATION="android.permission.ACCESS_FINE_LOCATION";
    private View view;
    private String lat=null;
    private String lng=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(" Book Your Current Leon");
        setSupportActionBar(toolbar);

        view=toolbar;
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
            this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        if (!checkPermission()) {

            requestPermission();

        }
       setHomeFragment(lat,lng);
    }



    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
//            super.onBackPressed();
        }
    }

   /* @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
*/
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        if (id == R.id.nav_my_home) {
            // Handle the camera action
            setHomeFragment(lat,lng);
        }
        else if (id == R.id.nav_my_order) {
            // Handle the camera action
            fragment=new MyOrderFragment();
            fragmentManager =getSupportFragmentManager();
            fragmentManager.beginTransaction()
                    .replace(R.id.main_frame, fragment)
                    .addToBackStack("")
                    .commit();
            getSupportActionBar().setTitle("My Order");
        } else if (id == R.id.nav_my_favorite) {
            fragment=new MyFavoriteFragment();
            fragmentManager =getSupportFragmentManager();
            fragmentManager.beginTransaction()
                    .replace(R.id.main_frame, fragment)
                    .addToBackStack("")
                    .commit();
            getSupportActionBar().setTitle("My Favorite");
        }  else if (id == R.id.nav_offers_discount) {
            fragment=new OffersFragment();
            fragmentManager =getSupportFragmentManager();
            fragmentManager.beginTransaction()
                    .replace(R.id.main_frame, fragment)
                    .addToBackStack("")
                    .commit();
            getSupportActionBar().setTitle("Offers & Discounts");
        } else if (id == R.id.nav_location_leon) {
            fragment=new leonLocationFragment();
            fragmentManager=getSupportFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.main_frame,fragment).addToBackStack("").commit();
            getSupportActionBar().setTitle("Leon Manual Location");
        } else if (id == R.id.nav_setting) {
            fragment=new SettingsFragment();
            fragmentManager=getSupportFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.main_frame,fragment).addToBackStack("").commit();
            getSupportActionBar().setTitle("Settings");
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    private boolean checkPermission() {
        int fineLocation = ContextCompat.checkSelfPermission(getApplicationContext(), FINE_LOCATION);
        /*int camera = ContextCompat.checkSelfPermission(getApplicationContext(), CAMERA);
        int storage = ContextCompat.checkSelfPermission(getApplicationContext(), STORAGE);
        int phoneState = ContextCompat.checkSelfPermission(getApplicationContext(), Phone_State);*/
        return fineLocation == PackageManager.PERMISSION_GRANTED;
                /*camera == PackageManager.PERMISSION_GRANTED &&
                storage == PackageManager.PERMISSION_GRANTED &&
                phoneState == PackageManager.PERMISSION_GRANTED */
    }
    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{FINE_LOCATION}, PERMISSION_REQUEST_CODE);
        /* , CAMERA,STORAGE,Phone_State*/
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0) {

                    boolean locationAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    if (locationAccepted) {
                        Snackbar.make(view, "Permission Granted, Now you can access location data and camera.", Snackbar.LENGTH_LONG).show();
                    }else {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (shouldShowRequestPermissionRationale(FINE_LOCATION)) {
                                showMessageOKCancel("You need to allow access to both the permissions",
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                    requestPermissions(new String[]{FINE_LOCATION},
                                                            PERMISSION_REQUEST_CODE);
                                                }
                                            }
                                        });
                                return;
                            }
                        }

                    }
                }


                break;
        }
    }
    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(MainActivity.this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    @Override
    public void fragmentCommunicationLocation(String lat, String lng) {
//        this.data=data1;
//        setHomeFragment(data);
        Bundle bundle = new Bundle();
        bundle.putString("lat", lat);
        bundle.putString("lng", lng);
        fragment=new HomeFragment();
        fragment.setArguments(bundle);
        fragmentManager =getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.main_frame, fragment)
                .addToBackStack("")
                .commit();
        getSupportActionBar().setTitle("Home");
    }

    /*@Override
    public void fragmentCommunicationHomeToLeongrill() {

        fragment=new leonLocationFragment();

        fragmentManager =getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.main_frame, fragment)
                .addToBackStack("")
                .commit();
        getSupportActionBar().setTitle("Leon Manual Location");
    }
*/
    private void setHomeFragment(String lat,String lng) {
        Bundle bundle = new Bundle();
        bundle.getString("lat", lat);
        bundle.getString("lng", lng);
        fragment=new HomeFragment();
        fragmentManager =getSupportFragmentManager();
        fragment.setArguments(bundle);
        fragmentManager.beginTransaction()
                .replace(R.id.main_frame, fragment)
                .addToBackStack("")
                .commit();
        getSupportActionBar().setTitle("Home");
    }
}
