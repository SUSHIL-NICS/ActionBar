package com.leongrill.nics.leongrill.Menu.Fragment;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import com.leongrill.nics.leongrill.Database.DatabaseHelper;
import com.leongrill.nics.leongrill.Menu.Adapter.ItemAdapter;
import com.leongrill.nics.leongrill.Menu.Dto.VegItemObject;
import com.leongrill.nics.leongrill.Menu.RecyclerItemClickListener;
import com.leongrill.nics.leongrill.R;
import com.leongrill.nics.leongrill.Utils.BadgeDrawable;
import com.leongrill.nics.leongrill.Utils.IFragmentCommunicator;

import java.util.ArrayList;


/**
 * Created by Savithri on 22-06-2017.
 */

@SuppressLint("ValidFragment")
public class MenuItemFragment extends Fragment {

    private RecyclerView recyclerView;
    private DatabaseHelper helper;
    private ArrayList<VegItemObject> items;
    private ItemAdapter itemAdapter;
    private TextView itemCount;
    private SharedPreferences sharedPreferences;
    private int count;
    private LayerDrawable mCartMenuIcon;
    // Store instance variables
    private String itemname;
    private int page;
    Context context;


    public static MenuItemFragment newInstance(int page, String title, Context context) {


        MenuItemFragment fragmentFirst = new MenuItemFragment(context);
        Bundle args = new Bundle();
        args.putInt("someInt", page);
        args.putString("someTitle", title);
        fragmentFirst.setArguments(args);
        return fragmentFirst;
    }

    public MenuItemFragment(){

    }

    public MenuItemFragment(Context context){
        this.context=context;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        helper=new DatabaseHelper(getContext());
        page = getArguments().getInt("someInt");
        itemname = getArguments().getString("someTitle");
        CopyData data=null;
        items=helper.fetchFromCart(itemname);
        if (items.size()==0) {
            data=new CopyData();
            data.execute(itemname);
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_veg,container,false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView=(RecyclerView)view.findViewById(R.id.veg_RecyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        StaggeredGridLayoutManager staggeredGridLayoutManager=new StaggeredGridLayoutManager(2,StaggeredGridLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(staggeredGridLayoutManager);
        itemAdapter=new ItemAdapter(getContext(),items);
        recyclerView.invalidate();
        recyclerView.setAdapter(itemAdapter);
        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getActivity(), new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, final int position) {
                final ImageButton cart= (ImageButton) view.findViewById(R.id.veg_add_to_card_imageButton);
                cart.setOnClickListener(new View.OnClickListener() {
                    int c=0;
                    @Override
                    public void onClick(View v) {
                        VegItemObject item=items.get(position);
                        if(item.getQuantity()==null) {
                            ++count;
                            if (count<10)
                                setBadgeCount(getContext(), mCartMenuIcon, "0"+count);
                            else if(count>0)
                                setBadgeCount(getContext(), mCartMenuIcon, count+"");
                            ++c;
                            item.setQuantity(c + "");
                            helper.updateCart(item.getItemName(), item.getQuantity());
                        }
                        else{
                            c=Integer.parseInt(item.getQuantity());
                            if(c==0){
                                ++count;
                                if (count<10)
                                    setBadgeCount(getContext(), mCartMenuIcon, "0"+count);
                                else if(count>0)
                                    setBadgeCount(getContext(), mCartMenuIcon, count+"");
                            }
                            ++c;
                            item.setQuantity(c+"");
                            helper.updateCart(item.getItemName(), item.getQuantity());
                        }
                    }
                });
            }
        }));
    }

    @Override
    public void onResume() {
        super.onResume();
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        count = sharedPreferences.getInt("itemcount", 0);
        if (count != 0 && mCartMenuIcon!=null) {
            if (count<10)
                setBadgeCount(getContext(), mCartMenuIcon, "0"+count);
            else
                setBadgeCount(getContext(), mCartMenuIcon, count+"");
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        //SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        if (sharedPreferences != null) {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putInt("itemcount", count);
            editor.apply();
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater)
    {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
        inflater.inflate(R.menu.order_menu, menu);
        mCartMenuIcon = (LayerDrawable) menu.findItem(R.id.action_cart).getIcon();
        if(mCartMenuIcon!=null){
            setBadgeCount(getContext(), mCartMenuIcon, count+"");}
    }

    class CopyData extends AsyncTask<String,Void,Void> {

        private ProgressDialog progressDialog;

        @Override
        protected Void doInBackground(String... params) {
            String brand=params[0];
            items = helper.getData(brand);
            for(VegItemObject item:items)
                helper.addToCart(item);
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //Showing progress dialog while sending email
            progressDialog = ProgressDialog.show(getContext(),"","Please wait...",false,false);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            //Dismissing the progress dialog
            progressDialog.dismiss();
            itemAdapter=new ItemAdapter(getActivity(),items);
            recyclerView.setAdapter(itemAdapter);
            itemAdapter.notifyDataSetChanged();

        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.action_cart:
                IFragmentCommunicator communicator= (IFragmentCommunicator) getActivity();
                communicator.fragmentCommunication();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public static void setBadgeCount(Context context, LayerDrawable icon, String count) {

        BadgeDrawable badge;

        // Reuse drawable if possible
        Drawable reuse = icon.findDrawableByLayerId(R.id.ic_badge);
        if (reuse != null && reuse instanceof BadgeDrawable) {
            badge = (BadgeDrawable) reuse;
        } else {
            badge = new BadgeDrawable(context);
        }

        badge.setCount(count);
        icon.mutate();
        icon.setDrawableByLayerId(R.id.ic_badge, badge);
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }
}
