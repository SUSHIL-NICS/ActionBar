package com.leongrill.nics.leongrill.Menu;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.leongrill.nics.leongrill.Drawer.MainActivity;
import com.leongrill.nics.leongrill.Menu.Fragment.MenuItemFragment;
import com.leongrill.nics.leongrill.R;
import com.leongrill.nics.leongrill.Utils.BadgeDrawable;
import com.leongrill.nics.leongrill.Utils.IFragmentCommunicator;

import java.util.HashMap;
import java.util.Map;

public class MenuActivity extends AppCompatActivity implements IFragmentCommunicator, ViewPager.OnPageChangeListener {
    private TabLayout tabLayout;
    private ViewPager viewPager;
    MyPagerAdapter adapterViewPager;
    private Button review_btn;
    private SharedPreferences sharedPreferences;
    Bundle bundle ;
    private LayerDrawable mCartMenuIcon;
    private int count;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        getSupportActionBar().setTitle("Menu Available");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        viewPager=(ViewPager)findViewById(R.id.menu_viewpager);
//        viewPager.setOffscreenPageLimit(2);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        adapterViewPager = new MyPagerAdapter(getSupportFragmentManager(),MenuActivity.this);
        viewPager.setAdapter(adapterViewPager);
        viewPager.getAdapter().notifyDataSetChanged();
        viewPager.setOnPageChangeListener(this);
        tabLayout=(TabLayout)findViewById(R.id.menu_tab_layout);
        assert tabLayout != null;
        tabLayout.post(new Runnable() {
            @Override
            public void run() {
                tabLayout.setupWithViewPager(viewPager);
                tabLayout.getSelectedTabPosition();
            }
        });
        review_btn=(Button)findViewById(R.id.veg_review_button);
        bundle = new Bundle();
        review_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmentCommunication();

            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.order_menu, menu);

       /* mCartMenuIcon = (LayerDrawable) menu.findItem(R.id.action_cart).getIcon();
        setBadgeCount(this, mCartMenuIcon, count+"");*/
        return true;
    }

    public static void setBadgeCount(Context context, LayerDrawable icon, String count) {

        BadgeDrawable badge;

        // Reuse drawable if possible
        Drawable reuse = icon.findDrawableByLayerId(R.id.ic_badge);
        if (reuse != null && reuse instanceof BadgeDrawable) {
            badge = (BadgeDrawable) reuse;
        } else {
            badge = new BadgeDrawable(context);
        }

        badge.setCount(count);
        icon.mutate();
        icon.setDrawableByLayerId(R.id.ic_badge, badge);
    }
    @Override
    protected void onResume() {
        super.onResume();
        if (sharedPreferences!=null) {
            sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
            String status = sharedPreferences.getString("formlist", "");
            if(status.equalsIgnoreCase("yes")){
                fragmentCommunication();
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("formlist", "no");
                editor.apply();
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case android.R.id.home:
                onBackPressed();
                break;
            case R.id.action_cart:
                fragmentCommunication();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {

        Intent i = new Intent(MenuActivity.this, MainActivity.class);
        startActivity(i);
        finish();
    }

    @Override
    public void fragmentCommunication() {
        Intent continueIntent=new Intent(MenuActivity.this,YourOrderDetailsActivity.class);
        startActivity(continueIntent);
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    public  class MyPagerAdapter extends FragmentPagerAdapter {
        private  int NUM_ITEMS = 3;
        Fragment fragment;
        private Map<Integer, String> mFragmentTags;
        private FragmentManager mFragmentManager;
        Context context;

        public MyPagerAdapter(FragmentManager fragmentManager, Context context) {
            super(fragmentManager);
            mFragmentManager = fragmentManager;
            mFragmentTags = new HashMap<Integer, String>();
            this.context=context;
        }


        // Returns total number of pages
        @Override
        public int getCount() {
            return NUM_ITEMS;
        }

        // Returns the fragment to display for that page
        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case 0: // Fragment # 0 - This will show FirstFragment
                    fragment= MenuItemFragment.newInstance(0,"veg",context);
                break;
                case 1: // Fragment # 0 - This will show FirstFragment different title
                    fragment= MenuItemFragment.newInstance(1,"nonVeg",context);
                    break;
                case 2: // Fragment # 1 - This will show SecondFragment
                    fragment= MenuItemFragment.newInstance(2,"dessert",context);
                    break;
                default:
                    fragment =null;
                    break;
            }
            return fragment;
        }
        @Override
        public CharSequence getPageTitle(int position) {
            switch (position){
                case 0:
                    return "Veg";
                case 1:
                    return "Non-Veg";
                case 2:
                    return "Dessert";
                default:
                    return null;
            }


        }

    }
}
