package com.leongrill.nics.leongrill;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

import com.leongrill.nics.leongrill.Database.DatabaseHelper;
import com.leongrill.nics.leongrill.Menu.Dto.VegItemObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Savithri on 20-06-2017.
 */

public class ItemService extends AsyncTask<String, Void, Void> {
    private Context context;
    private ProgressDialog pDialog;
    private DatabaseHelper helper;
    private List<VegItemObject> itemList;

    public ItemService(Context context, DatabaseHelper helper) {
        this.context = context;
        this.helper = helper;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        super.onPreExecute();
        pDialog =  new ProgressDialog(context, ProgressDialog.STYLE_SPINNER);
        pDialog.setIndeterminate(true);
        pDialog.show(context, "LeonGrill", "Processing.....");

    }
    @Override
    protected Void doInBackground(String... params) {
//        String response=params[0];
        itemList = getAllMileStoneObject();
        helper.insertItems(itemList);
        return null;
    }

    @Override
    protected void onPostExecute(Void result) {
        super.onPostExecute(result);
        if (pDialog != null) {
            pDialog.cancel();
        }

    }
    public List<VegItemObject> getAllMileStoneObject(){
        ArrayList<VegItemObject> mList=new ArrayList<>();

        //category veg item
        mList.add(new VegItemObject("1",R.drawable.burger_combo,"Burger Combo"," 150.00","veg"));

        mList.add(new VegItemObject("2",R.drawable.doner_combo,"Donner Combo"," 250.00","veg"));

        mList.add(new VegItemObject("3",R.drawable.falafal_doner_salad," Falafal Donner Salad "," 120.00","veg"));

        mList.add(new VegItemObject("4",R.drawable.paneer_peri_peri_wrap,"Pannier Peri Peri Wrap","140.00","veg"));

        mList.add(new VegItemObject("5",R.drawable.peri_peri_paneer_salad," Peri Peri Pannier Salad " ,"150.00","veg"));

        mList.add(new VegItemObject("6",R.drawable.vegburger," Vegeburger ","80.00","veg"));

        mList.add(new VegItemObject("7",R.drawable.burger_combo,"Burger Combo pack"," 150.00","veg"));

        mList.add(new VegItemObject("8",R.drawable.doner_combo,"Donner Combo pack"," 250.00","veg"));

        mList.add(new VegItemObject("9",R.drawable.falafal_doner_salad," Falafal Donner Salad combo "," 120.00","veg"));

        mList.add(new VegItemObject("10",R.drawable.paneer_peri_peri_wrap,"Pannier Peri Peri Wrap combo","140.00","veg"));

        //category non veg
        mList.add(new VegItemObject("11",R.drawable.burger_combo,"Chicken Burger Combo"," 150.00","nonVeg"));

        mList.add(new VegItemObject("12",R.drawable.doner_combo,"Chicken Donner Combo"," 250.00","nonVeg"));

        mList.add(new VegItemObject("13",R.drawable.falafal_doner_salad," Chicken Falafal Donner Salad "," 120.00","nonVeg"));

        mList.add(new VegItemObject("14",R.drawable.paneer_peri_peri_wrap,"chicken Pannier Peri Peri Wrap","140.00","nonVeg"));

        mList.add(new VegItemObject("15",R.drawable.peri_peri_paneer_salad," Chicken Peri Peri Pannier Salad " ,"150.00","nonVeg"));

        mList.add(new VegItemObject("16",R.drawable.vegburger,"Chicken  Vegeburger ","80.00","nonVeg"));

        mList.add(new VegItemObject("17",R.drawable.burger_combo," Chicken Burger"," 150.00","nonVeg"));

        mList.add(new VegItemObject("18",R.drawable.doner_combo,"Chicken Donner"," 250.00","nonVeg"));

        mList.add(new VegItemObject("19",R.drawable.falafal_doner_salad,"Chicken  Falafal "," 120.00","nonVeg"));

        mList.add(new VegItemObject("20",R.drawable.paneer_peri_peri_wrap,"Chicken Pannier Peri Peri","140.00","nonVeg"));

//category dessert
        mList.add(new VegItemObject("21",R.drawable.burger_combo,"Chicken Burger Combo dessert"," 150.00","dessert"));

        mList.add(new VegItemObject("22",R.drawable.doner_combo," Donner Combo dessert 1"," 250.00","dessert"));

        mList.add(new VegItemObject("23",R.drawable.falafal_doner_salad," Chicken Falafal Donner Salad dessert "," 120.00","dessert"));

        mList.add(new VegItemObject("24",R.drawable.paneer_peri_peri_wrap,"chicken Pannier Peri Peri Wrap dessert","140.00","dessert"));

        mList.add(new VegItemObject("25",R.drawable.peri_peri_paneer_salad,"  Peri Peri Pannier Salad dessert " ,"150.00","dessert"));

        mList.add(new VegItemObject("26",R.drawable.vegburger,"Chicken  Vegeburger dessert ","80.00","dessert"));

        mList.add(new VegItemObject("27",R.drawable.burger_combo," Chicken Burger Combo dessert1"," 150.00","dessert"));

        mList.add(new VegItemObject("28",R.drawable.doner_combo," Donner Combo dessert11"," 250.00","dessert"));

        mList.add(new VegItemObject("29",R.drawable.falafal_doner_salad,"  Falafal Donner Salad dessert "," 120.00","dessert"));

        mList.add(new VegItemObject("30",R.drawable.paneer_peri_peri_wrap,"Chicken Pannier Peri Peri Wrap dessert 1","140.00","dessert"));

        return mList;

    }

}
