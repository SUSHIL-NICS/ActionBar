package com.leongrill.nics.leongrill;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.leongrill.nics.leongrill.Database.DatabaseHelper;
import com.leongrill.nics.leongrill.Drawer.MainActivity;
import com.leongrill.nics.leongrill.Utils.NetworkConnectivity;

public class SplashScreen extends AppCompatActivity {

    private DatabaseHelper helper;
    private NetworkConnectivity connectivity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        connectivity=new NetworkConnectivity(this);
        helper=new DatabaseHelper(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash_screen);
        final ImageView im= (ImageView) findViewById(R.id.Leon_image_place_deep);

        final Animation an= AnimationUtils.loadAnimation(getBaseContext(),R.anim.move);
        final Animation an1= AnimationUtils.loadAnimation(getBaseContext(),R.anim.abc_fade_out);

        im.startAnimation(an);
        /*an.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                im.startAnimation(an1);
                finish();
                Intent i=new Intent(getBaseContext(),MainActivity.class);
                startActivity(i);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });*/
    }

    @Override
    protected void onResume() {
        super.onResume();
        final int count=helper.fetchUserCount();
        final int itemcount=helper.getItemCount();
            final int splashtime = 4000;
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (connectivity.isConnected() && itemcount==0) {
                        requestData();
                    }
                    Intent i=null;
                    i = new Intent(SplashScreen.this, MainActivity.class);
                    startActivity(i);

                }
            }, splashtime);

    }

    private void requestData() {

        ItemService service=new ItemService(SplashScreen.this,helper);
        service.execute();
        /*Intent i=null;
        i = new Intent(SplashScreen.this, MainActivity.class);
        startActivity(i);*/
    }
}



