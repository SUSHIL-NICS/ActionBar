package com.leongrill.nics.leongrill.Menu.Dto;

/**
 * Created by Savithri on 12-06-2017.
 */

public class NonVegItemObject {
    private String price;
    private String name;
    private int image;


    public NonVegItemObject(int image, String name, String price){
        this.image=image;
        this.name=name;
        this.price=price;
    }


    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }



    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }




}
