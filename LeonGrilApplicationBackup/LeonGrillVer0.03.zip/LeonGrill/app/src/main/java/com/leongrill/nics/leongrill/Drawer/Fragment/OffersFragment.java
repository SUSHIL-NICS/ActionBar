package com.leongrill.nics.leongrill.Drawer.Fragment;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bignerdranch.expandablerecyclerview.Model.ParentObject;
import com.leongrill.nics.leongrill.Drawer.Adapter.OffersFragmentAdapter;
import com.leongrill.nics.leongrill.Drawer.Dto.OfferFragmentChild;
import com.leongrill.nics.leongrill.Drawer.Dto.OfferFragmentCreator;
import com.leongrill.nics.leongrill.Drawer.Dto.OfferFragmentParent;

import com.leongrill.nics.leongrill.Drawer.MainActivity;
import com.leongrill.nics.leongrill.R;

import java.util.ArrayList;
import java.util.List;


public class OffersFragment extends Fragment {

    RecyclerView recyclerView;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_offers,container,false);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        ((OffersFragmentAdapter)recyclerView.getAdapter()).onSaveInstanceState(outState);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView= (RecyclerView) view.findViewById(R.id.supplier_recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        OffersFragmentAdapter adapter=new OffersFragmentAdapter(getContext(),initData());
        adapter.setParentClickableViewAnimationDefaultDuration();
        adapter.setParentAndIconExpandOnClick(true);
        recyclerView.setAdapter(adapter);
    }

    private List<ParentObject> initData() {
        OfferFragmentCreator tc= OfferFragmentCreator.get(getContext());
        List<OfferFragmentParent> lis=tc.getAll();
        List<ParentObject> parntObjt=new ArrayList<>();
        for (OfferFragmentParent title:lis){
            List<Object> childlist=new ArrayList<>();
            childlist.add(new OfferFragmentChild("hii buddy","Get Lost"));
            title.setChildObjectList(childlist);
            parntObjt.add(title);
        }
        return parntObjt;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction()==KeyEvent.ACTION_DOWN){
                    if(keyCode==KeyEvent.KEYCODE_BACK){
                        Intent intent=new Intent(getActivity(), MainActivity.class);
                        startActivity(intent);
                        return true;
                    }
                }
                return false;
            }
        });
    }
}
