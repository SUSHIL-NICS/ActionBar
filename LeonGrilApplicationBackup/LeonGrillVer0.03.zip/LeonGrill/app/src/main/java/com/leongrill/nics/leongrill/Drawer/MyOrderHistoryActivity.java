package com.leongrill.nics.leongrill.Drawer;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;

import com.leongrill.nics.leongrill.Database.DatabaseHelper;
import com.leongrill.nics.leongrill.Drawer.Adapter.MyOrderAdapter;
import com.leongrill.nics.leongrill.Drawer.Adapter.OrderHistoryAdapter;
import com.leongrill.nics.leongrill.Drawer.Dto.OrderHistoryDto;
import com.leongrill.nics.leongrill.R;

import java.util.ArrayList;

public class MyOrderHistoryActivity extends AppCompatActivity {

    private DatabaseHelper helper;
    private RecyclerView recyclerView;
    private ArrayList<OrderHistoryDto> orderHistoryDtoList;
    private OrderHistoryAdapter orderHistoryAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_order_history);
        recyclerView=(RecyclerView)findViewById(R.id.order_history_list_recyclerview);
        helper=new DatabaseHelper(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("OrderHistory");
        Intent intent=getIntent();
        String dateTime=intent.getStringExtra("historyList");
        orderHistoryDtoList=helper.fetchFromOrderHistoryListData(dateTime);
       // LinearLayoutManager layoutManager = new LinearLayoutManager(MyOrderHistoryActivity.this);
        recyclerView.setLayoutManager( new LinearLayoutManager(this));
        orderHistoryAdapter=new OrderHistoryAdapter(orderHistoryDtoList,this);
        recyclerView.setAdapter(orderHistoryAdapter);
    }
    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                onBackPressed();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
