package com.leongrill.nics.leongrill.Menu.Fragment;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.leongrill.nics.leongrill.Database.DatabaseHelper;
import com.leongrill.nics.leongrill.Menu.Adapter.ItemAdapter;
import com.leongrill.nics.leongrill.Menu.Dto.ItemObject;
import com.leongrill.nics.leongrill.Menu.RecyclerItemClickListener;
import com.leongrill.nics.leongrill.PreferenceHelper;
import com.leongrill.nics.leongrill.R;
import com.leongrill.nics.leongrill.Utils.BadgeDrawable;
import com.leongrill.nics.leongrill.Utils.IFragmentCommunicator;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;


/**
 * Created by Savithri on 22-06-2017.
 */

@SuppressLint("ValidFragment")
public class ItemFragment extends Fragment {

    private static final String TAG =ItemFragment.class.getSimpleName() ;
    private RecyclerView recyclerView;
    private DatabaseHelper helper;
    private ArrayList<ItemObject> items;
    private ItemAdapter itemAdapter;
    private int count;
    private int cal=0;
    private LayerDrawable mCartMenuIcon;
    private String itemname;
    public ImageButton favourite;
    public ImageButton cart;
    private int page;
    PreferenceHelper preferenceHelper;

    public static ItemFragment newInstance(int page, String title) {
        ItemFragment fragmentFirst = new ItemFragment();
        Bundle args = new Bundle();
        args.putInt("someInt", page);
        args.putString("someTitle", title);
        fragmentFirst.setArguments(args);
        return fragmentFirst;
    }

    public ItemFragment(){

    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        helper=new DatabaseHelper(getContext());
        preferenceHelper=new PreferenceHelper(getContext());
        page = getArguments().getInt("someInt");
        itemname = getArguments().getString("someTitle");
        if (page==0){
            items=helper.fetchFromCart(itemname);
        }else if (page==1){
            items=helper.fetchFromCart(itemname);
        }else if (page==2){
            items=helper.fetchFromCart(itemname);

        }

        if (items.size()==0) {
            items = helper.getData(itemname);
            for(ItemObject item:items)
                helper.addToCart(item);
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_veg,container,false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        page = getArguments().getInt("someInt");
        recyclerView=(RecyclerView)view.findViewById(R.id.veg_RecyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        StaggeredGridLayoutManager staggeredGridLayoutManager=new StaggeredGridLayoutManager(2,StaggeredGridLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(staggeredGridLayoutManager);
        itemAdapter=new ItemAdapter(getContext(),items);
        recyclerView.invalidate();
        recyclerView.setAdapter(itemAdapter);
        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getActivity(), new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public  void onItemClick(final View view, final int position) {

                cart= (ImageButton) view.findViewById(R.id.veg_add_to_card_imageButton);
                favourite= (ImageButton) view.findViewById(R.id.add_favorite_imageButton);

                cart.setOnClickListener(new View.OnClickListener() {
                    int c=0;
                    @Override
                    public void onClick(View v) {
                        ItemObject item=items.get(position);
                        if(item.getQuantity()==null) {
                            ++count;
                            if (count<10)
                                setBadgeCount(getContext(), mCartMenuIcon, "0"+count);
                            else if(count>0)
                                setBadgeCount(getContext(), mCartMenuIcon, count+"");
                            ++c;
                            item.setQuantity(c + "");
                            helper.updateCart(item.getItemName(), item.getQuantity());
                        }else{
                            c=Integer.parseInt(item.getQuantity());
                            if(c==0){
                                ++count;
                                if (count<10)
                                    setBadgeCount(getContext(), mCartMenuIcon, "0"+count);
                                else if(count>0)
                                    setBadgeCount(getContext(), mCartMenuIcon, count+"");

                                ++c;
                                item.setQuantity(c+"");
                                helper.updateCart(item.getItemName(), item.getQuantity());
                            }
                            else {

                                Snackbar snackbar = Snackbar.make(view.findViewById(R.id.veg_add_to_card_imageButton),
                                        " Item already has been Bagged .", Snackbar.LENGTH_LONG);
                                View sbView = snackbar.getView();
                                TextView textView = (TextView) sbView.findViewById(android.support.design.R.id.snackbar_text);
                                textView.setTextColor(Color.RED);
                                snackbar.show();
                            }
                        }
                    }
                });

                favourite.setOnClickListener(new View.OnClickListener() {
                    int c=0;
                    public void onClick(View button) {
                            ItemObject item=items.get(position);
                            button.setSelected(!button.isSelected());
                        if (button.isSelected()) {
                                favourite.setImageResource(R.drawable.ic_favourite_heartred);
                                ++c;
                                cal++;
                                item.setFavorite(c + "");
                                Log.i(TAG, "" + item.getId());
                                helper.updateFavorite(item.getItemName(), item.getFavorite());                            }
                            else {
                                favourite.setImageResource(R.drawable.ic_favourite_heartwhite);
                                cal--;
                                helper.updateFavorite(item.getItemName(),"0");
                            }
                     }
                });

            }
        }));
    }

    @Override
    public void onResume() {
        super.onResume();
        count= preferenceHelper.getCountFormSharedPreference("itemCount");
        if (count != 0 && mCartMenuIcon!=null) {
            if (count<10)
                setBadgeCount(getContext(), mCartMenuIcon, ""+count);
            else
                setBadgeCount(getContext(), mCartMenuIcon, count+"");

        }
   ArrayList<ItemObject> i=helper.getCartItemFavorite();
        if(i.size()==0)
        {
            itemAdapter.notifyDataSetChanged();
            itemAdapter.selectAllFavouriteItem(false);

        } else
        {
            itemAdapter.notifyDataSetChanged();
            itemAdapter.selectAllFavouriteItem(true);

        }

       /* if(cal ==1)
        {
           // favourite.setBackgroundResource(R.drawable.star_yellow);
            //ItemAdapter.MyViewHolder.fav_imb.setBackgroundResource(R.drawable.star_yellow);
           *//* favourite= (ImageButton)findViewById(R.id.add_favorite_imageButton);
            boolean isFavourite = readStae();
            favourite.setBackgroundResource(R.drawable.star_yellow);
            isFavourite = false;
            saveStae(isFavourite);*//*
        }
        else if(cal==0)
        {
//           favourite.setBackgroundResource(R.drawable.star_white);
        }*/
    }

    @Override
    public void onPause() {
        super.onPause();
        preferenceHelper.SaveCountToSharedPreference("itemCount",count);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater)
    {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
        inflater.inflate(R.menu.order_menu, menu);
        mCartMenuIcon = (LayerDrawable) menu.findItem(R.id.action_cart).getIcon();
        if(mCartMenuIcon!=null){
            setBadgeCount(getContext(), mCartMenuIcon, count+"");}
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_cart:
                IFragmentCommunicator communicator= (IFragmentCommunicator) getActivity();
                communicator.fragmentCommunication();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public static void setBadgeCount(Context context, LayerDrawable icon, String count) {

        BadgeDrawable badge;

        // Reuse drawable if possible
        Drawable reuse = icon.findDrawableByLayerId(R.id.ic_badge);
        if (reuse != null && reuse instanceof BadgeDrawable) {
            badge = (BadgeDrawable) reuse;
        } else {
            badge = new BadgeDrawable(context);
        }

        badge.setCount(count);
        icon.mutate();
        icon.setDrawableByLayerId(R.id.ic_badge, badge);
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }


    class CopyData extends AsyncTask<String,Void,Void> {

        private ProgressDialog progressDialog;

        @Override
        protected Void doInBackground(String... params) {
            String brand=params[0];
            items = helper.getData(brand);
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //Showing progress dialog while sending email
            progressDialog = ProgressDialog.show(getContext(),"","Please wait...",false,false);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            //Dismissing the progress dialog
            progressDialog.dismiss();
          /*  itemAdapter=new ItemAdapter(getContext(),items);
            recyclerView.setAdapter(itemAdapter);
            itemAdapter.notifyDataSetChanged();*/

        }
    }
}
