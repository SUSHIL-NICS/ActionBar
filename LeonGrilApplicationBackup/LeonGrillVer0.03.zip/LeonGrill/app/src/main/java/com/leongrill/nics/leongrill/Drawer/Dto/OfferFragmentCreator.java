package com.leongrill.nics.leongrill.Drawer.Dto;

import android.content.Context;


import com.leongrill.nics.leongrill.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by NIC-BISWA on 05-06-2017.
 */
public class OfferFragmentCreator {
    static OfferFragmentCreator _titleCreator;
    List<OfferFragmentParent> _titleParent;

    public OfferFragmentCreator(Context context) {
        _titleParent = new ArrayList<OfferFragmentParent>();
        for (int i = 0; i <= 10; i++) {
            OfferFragmentParent supplierDiscount = new OfferFragmentParent("20% Discount", "Burger Combo", R.drawable.burger_combo, i);
            _titleParent.add(supplierDiscount);

        }
    }

    public static OfferFragmentCreator get(Context context) {
        if (_titleCreator == null)
            _titleCreator = new OfferFragmentCreator(context);
        return _titleCreator;
    }

    public List<OfferFragmentParent> getAll() {
        return  _titleParent;
    }
}
