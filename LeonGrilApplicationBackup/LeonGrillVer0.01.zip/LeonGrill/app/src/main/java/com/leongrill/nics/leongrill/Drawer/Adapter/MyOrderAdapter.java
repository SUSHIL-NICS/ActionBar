package com.leongrill.nics.leongrill.Drawer.Adapter;


import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.leongrill.nics.leongrill.Drawer.Dto.OrderHistoryDto;
import com.leongrill.nics.leongrill.R;

import java.util.ArrayList;
import java.util.List;
//import android.support.v7.widget.PopupMenu;

public class MyOrderAdapter extends RecyclerView.Adapter<MyOrderAdapter.MyViewHolder>{
    private ArrayList<String> list_item;
    private Context context;

    public MyOrderAdapter(ArrayList<String> list_item, Context context) {
        this.list_item = list_item;
        this.context = context;
    }

    //Called when RecyclerView needs a new RecyclerView.ViewHolder of the given type to represent an item.

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent,int viewType) {
        //create a layout
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.content_my_order_fragment, null);

        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }


    // Called by RecyclerView to display the data at the specified position.
    @Override
    public void onBindViewHolder(final MyViewHolder myViewHolder, final int position ) {
        String  date = list_item.get(position);
        myViewHolder.store_name.setText(date);



    }

    @Override
    public int getItemCount() {
        return list_item.size();
    }

    // initializes some private fields to be used by RecyclerView.
    public static class MyViewHolder extends RecyclerView.ViewHolder  {
        public TextView store_name;
        public MyViewHolder(View itemLayoutView) {
            super(itemLayoutView);
            store_name = (TextView) itemLayoutView.findViewById(R.id.history_item);
 }
    }


}

