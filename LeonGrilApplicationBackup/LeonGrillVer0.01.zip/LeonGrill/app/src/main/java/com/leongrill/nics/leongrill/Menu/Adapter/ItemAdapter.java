package com.leongrill.nics.leongrill.Menu.Adapter;


import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.leongrill.nics.leongrill.Menu.Dto.ItemObject;
import com.leongrill.nics.leongrill.R;

import java.util.ArrayList;

/**
 * Created by Savithri on 20-06-2017.
 */

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.MyViewHolder>{

    private Context context;
    private ArrayList<ItemObject> items;
    private LayoutInflater layoutInflater;
    public ItemAdapter(Context context, ArrayList<ItemObject> items) {
        this.context=context;
        this.items=items;
        layoutInflater=LayoutInflater.from(context);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view=layoutInflater.inflate(R.layout.containt_veg_menu_fragment,parent,false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        ItemObject ItemObject=items.get(position);
        holder.name_tv.setText(ItemObject.getItemName());
        holder.price_tv.setText(ItemObject.getPrice());
        holder.background_imv.setImageResource(ItemObject.getImage());
        if(ItemObject.getQuantity()!=null && !ItemObject.getQuantity().equalsIgnoreCase("0")){

        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder{
        public TextView name_tv;
        public TextView price_tv;
        public ImageView background_imv;
        public ImageButton addToCard_imb;
        public static ImageButton fav_imb;
        public MyViewHolder(View view){
            super(view);
            name_tv = (TextView)view.findViewById(R.id.veg_name_textView);
            price_tv = (TextView)view.findViewById(R.id.veg_price_textView);
            background_imv = (ImageView) view.findViewById(R.id.veg_imageView);
            addToCard_imb = (ImageButton) view.findViewById(R.id.veg_add_to_card_imageButton);
            fav_imb = (ImageButton) view.findViewById(R.id.add_favorite_imageButton);
        }
    }
}
