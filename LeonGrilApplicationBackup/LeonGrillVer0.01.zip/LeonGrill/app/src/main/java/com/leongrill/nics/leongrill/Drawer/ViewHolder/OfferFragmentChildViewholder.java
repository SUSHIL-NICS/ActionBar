package com.leongrill.nics.leongrill.Drawer.ViewHolder;

import android.view.View;
import android.widget.TextView;

import com.bignerdranch.expandablerecyclerview.ViewHolder.ChildViewHolder;
import com.leongrill.nics.leongrill.R;


/**
 * Created by NIC-BISWA on 05-06-2017.
 */
public class OfferFragmentChildViewholder extends ChildViewHolder {
    public TextView option1;
    public TextView option2;
    public OfferFragmentChildViewholder(View itemView) {
        super(itemView);
        option1= (TextView) itemView.findViewById(R .id.option1);
        option2= (TextView) itemView.findViewById(R.id.option2);

    }
}
