package com.leongrill.nics.leongrill.Menu;



import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.LayerDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.leongrill.nics.leongrill.Drawer.MainActivity;
import com.leongrill.nics.leongrill.Menu.Fragment.MenuItemFragment;
import com.leongrill.nics.leongrill.Notification.NotificationCountSetClass;
import com.leongrill.nics.leongrill.R;
import com.leongrill.nics.leongrill.Utils.IFragmentCommunicator;

import java.util.ArrayList;
import java.util.List;

public class MenuItemActivity extends AppCompatActivity implements IFragmentCommunicator {

    public static int notificationCountCart = 0;
    static ViewPager viewPager;
    static TabLayout tabLayout;
    private Button review_btn;
    SharedPreferences sharedPreferences;
    LayerDrawable mCartMenuIcon;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        getSupportActionBar().setTitle("Menu Available");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        review_btn=(Button)findViewById(R.id.veg_review_button);
        review_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmentCommunication();

            }
        });
        viewPager = (ViewPager) findViewById(R.id.menu_viewpager);
        tabLayout = (TabLayout) findViewById(R.id.menu_tab_layout);
            setupViewPager(viewPager);
            tabLayout.setupWithViewPager(viewPager);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.order_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        // Get the notifications MenuItem and
        // its LayerDrawable (layer-list)
        MenuItem item = menu.findItem(R.id.action_cart);
        NotificationCountSetClass.setAddToCart(MenuItemActivity.this, item,notificationCountCart);
        // force the ActionBar to relayout its MenuItems.
        // onCreateOptionsMenu(Menu) will be called again.
        invalidateOptionsMenu();
        return super.onPrepareOptionsMenu(menu);
    }


    @Override
    protected void onResume() {
        super.onResume();
        invalidateOptionsMenu();
    }

  /* @Override
   public void onResume() {
       super.onResume();
       sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
       count = sharedPreferences.getInt("itemcount", 0);
       if (count != 0 && mCartMenuIcon!=null) {
           if (count<10)
               setBadgeCount(MenuItemActivity.this, mCartMenuIcon, ""+count);
           else
               setBadgeCount(MenuItemActivity.this, mCartMenuIcon, count+"");
       }
   }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case android.R.id.home:
                onBackPressed();
                break;
            case R.id.action_cart:
                fragmentCommunication();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {

        Intent i = new Intent(MenuItemActivity.this, MainActivity.class);
        startActivity(i);
        finish();
    }

    @Override
    public void fragmentCommunication() {
        Intent continueIntent=new Intent(MenuItemActivity.this,YourOrderDetailsActivity.class);
        startActivity(continueIntent);
    }

    private void setupViewPager(ViewPager viewPager) {
        Adapter adapter = new Adapter(getSupportFragmentManager());
        MenuItemFragment fragment = new MenuItemFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("type", 1);
        fragment.setArguments(bundle);
        adapter.addFragment(fragment, getString(R.string.item_1));
        fragment = new MenuItemFragment();
        bundle = new Bundle();
        bundle.putInt("type", 2);
        fragment.setArguments(bundle);
        adapter.addFragment(fragment, getString(R.string.item_2));
        fragment = new MenuItemFragment();
        bundle = new Bundle();
        bundle.putInt("type", 3);
        fragment.setArguments(bundle);
        adapter.addFragment(fragment, getString(R.string.item_3));
        viewPager.setAdapter(adapter);
    }

    static class Adapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragments = new ArrayList<>();
        private final List<String> mFragmentTitles = new ArrayList<>();

        public Adapter(FragmentManager fm) {
            super(fm);
        }

        public void addFragment(Fragment fragment, String title) {
            mFragments.add(fragment);
            mFragmentTitles.add(title);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragments.get(position);
        }

        @Override
        public int getCount() {
            return mFragments.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitles.get(position);
        }
    }
}
