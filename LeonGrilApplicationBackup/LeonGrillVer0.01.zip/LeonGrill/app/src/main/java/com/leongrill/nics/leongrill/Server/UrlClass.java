package com.leongrill.nics.leongrill.Server;

/**
 * Created by Savithri on 19-06-2017.
 */

public class UrlClass {
}
