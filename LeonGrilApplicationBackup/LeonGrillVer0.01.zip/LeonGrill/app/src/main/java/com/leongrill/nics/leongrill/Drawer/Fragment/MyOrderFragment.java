package com.leongrill.nics.leongrill.Drawer.Fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.leongrill.nics.leongrill.Database.DatabaseHelper;
import com.leongrill.nics.leongrill.Drawer.Adapter.MyOrderAdapter;
import com.leongrill.nics.leongrill.Drawer.ClickListener;
import com.leongrill.nics.leongrill.Drawer.Dto.OrderHistoryDto;
import com.leongrill.nics.leongrill.Drawer.FragmentCommunicator;
import com.leongrill.nics.leongrill.Drawer.MainActivity;
import com.leongrill.nics.leongrill.Drawer.MyOrderHistoryActivity;
import com.leongrill.nics.leongrill.Menu.RecyclerItemClickListener;
import com.leongrill.nics.leongrill.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Savithri on 13-06-2017.
 */

public class MyOrderFragment extends Fragment {
    private MyOrderAdapter myOrderAdapter;
    private RecyclerView my_order_RecyclerView;
    private DatabaseHelper helper;
    private  ArrayList<String> historyListDate;
    private RelativeLayout order_history_empty_transparent;
    private RelativeLayout order_history_empty_rv;
    private AppCompatButton order_history_btn;

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_order,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        helper=new DatabaseHelper(getContext());
        my_order_RecyclerView = (RecyclerView) view.findViewById(R.id.my_order_RecyclerView);
        order_history_empty_rv=(RelativeLayout) view.findViewById(R.id.order_history_empty_rv);
        order_history_empty_transparent = (RelativeLayout) view.findViewById(R.id.order_history_empty_transparent);
        order_history_btn = (AppCompatButton) view.findViewById(R.id.orderHistory_bt);
        order_history_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentCommunicator communicator= (FragmentCommunicator) getActivity();
                communicator.fragmentCommunication();
            }
        });

        historyListDate=helper.fetchFromOrderHistoryList();
        if(historyListDate.size()==0){
            order_history_empty_transparent.setVisibility(View.VISIBLE);
            order_history_empty_rv.setVisibility(View.VISIBLE);
            my_order_RecyclerView.setVisibility(View.INVISIBLE);
        }
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        my_order_RecyclerView.setLayoutManager(layoutManager);
        myOrderAdapter=new MyOrderAdapter(historyListDate,getContext());
        my_order_RecyclerView.setAdapter(myOrderAdapter);
        my_order_RecyclerView.addOnItemTouchListener(new RecyclerItemTouchClickListener(getContext(),my_order_RecyclerView, new ClickListener() {
            @Override
            public void OnClick(View view, int position) {
                String historyItem=historyListDate.get(position);
                String[] historyArray=null;
                try{
                    historyArray=historyItem.split("\\(");
                }catch (Exception e){
                    e.printStackTrace();
                }
                Intent intent=new Intent(getContext(),MyOrderHistoryActivity.class);
                intent.putExtra("historyList",historyArray[0]);
                startActivity(intent);
            }
        }));

    }

    class RecyclerItemTouchClickListener implements RecyclerView.OnItemTouchListener {
         private ClickListener clickListener;
         private GestureDetector gestureDetector;

        public RecyclerItemTouchClickListener(Context context, final RecyclerView recyclerView,final ClickListener clickListener) {
            this.clickListener=clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                        @Override
                        public boolean onSingleTapUp(MotionEvent e) {
                            return true;
                        }
               /* @Override
                public void onLongPress(MotionEvent e){
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.OnClick(child, recyclerView.getChildAdapterPosition(child));
                    }
                }*/
            });
        }

         @RequiresApi(api = Build.VERSION_CODES.GINGERBREAD)
         @Override
         public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

             View childView = rv.findChildViewUnder(e.getX(), e.getY());
             if (childView != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                 clickListener.OnClick(childView, rv.getChildAdapterPosition(childView));
             }

             return false;



         }
         @Override
         public void onTouchEvent(RecyclerView recyclerView, MotionEvent motionEvent) {

         }

         @Override
         public void onRequestDisallowInterceptTouchEvent(boolean b) {

         }
     }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction()==KeyEvent.ACTION_DOWN){
                    if(keyCode==KeyEvent.KEYCODE_BACK){
                        Intent intent=new Intent(getActivity(), MainActivity.class);
                        startActivity(intent);
                        return true;
                    }
                }
                return false;
            }
        });
    }
    @Override
    public void onResume() {
        super.onResume();
        if(historyListDate.size()==0){
            order_history_empty_rv.setVisibility(View.VISIBLE);
            order_history_empty_transparent.setVisibility(View.VISIBLE);
            my_order_RecyclerView.setVisibility(View.INVISIBLE);
        }
    }

}
