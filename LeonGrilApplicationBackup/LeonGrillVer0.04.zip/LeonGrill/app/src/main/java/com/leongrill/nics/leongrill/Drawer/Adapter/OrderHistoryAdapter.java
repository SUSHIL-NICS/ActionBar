package com.leongrill.nics.leongrill.Drawer.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.leongrill.nics.leongrill.Drawer.Dto.OrderHistoryDto;
import com.leongrill.nics.leongrill.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sushil on 04-07-2017.
 */
public class OrderHistoryAdapter  extends RecyclerView.Adapter<OrderHistoryAdapter.MyViewHolder> {
    private ArrayList<OrderHistoryDto> list_item;
    private Context context;

    public OrderHistoryAdapter(ArrayList<OrderHistoryDto> list_item, Context context) {
        this.list_item = list_item;
        this.context = context;
    }

    //Called when RecyclerView needs a new RecyclerView.ViewHolder of the given type to represent an item.

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //create a layout
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.content_my_order_history_list_fragment, null);

        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }


    // Called by RecyclerView to display the data at the specified position.
    @Override
    public void onBindViewHolder(final MyViewHolder myViewHolder, final int position) {
        OrderHistoryDto orderHistoryDto = list_item.get(position);
        myViewHolder.history_list_item_name.setText(orderHistoryDto.getName());
        myViewHolder.history_list_item_price.setText(" Unit Price : "+orderHistoryDto.getPrice());
        myViewHolder.history_list_item_quatity.setText(" Quantity "+orderHistoryDto.getQuantity());
        myViewHolder.bak_image.setImageResource(orderHistoryDto.getImage());
    }

    @Override
    public int getItemCount() {
        return list_item.size();
    }

    // initializes some private fields to be used by RecyclerView.
    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView history_list_item_name;
        public TextView history_list_item_price;
        public TextView history_list_item_quatity;
        public ImageView bak_image;
        public MyViewHolder(View itemLayoutView) {
            super(itemLayoutView);
            history_list_item_name = (TextView) itemLayoutView.findViewById(R.id.history_list_item_name);
            history_list_item_price=(TextView) itemLayoutView.findViewById(R.id.history_list_item_price);
            history_list_item_quatity=(TextView) itemLayoutView.findViewById(R.id.history_list_item_quatity);
            bak_image=(ImageView) itemLayoutView.findViewById(R.id.history_productImage_imageView);
        }
    }
}
