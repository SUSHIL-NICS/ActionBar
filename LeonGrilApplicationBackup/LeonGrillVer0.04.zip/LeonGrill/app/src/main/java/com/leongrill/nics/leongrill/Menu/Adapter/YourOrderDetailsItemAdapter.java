package com.leongrill.nics.leongrill.Menu.Adapter;


import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import com.leongrill.nics.leongrill.Menu.Dto.ItemObject;
import com.leongrill.nics.leongrill.R;

import java.util.ArrayList;

/**
 * Created by Savithri on 13-06-2017.
 */
public class YourOrderDetailsItemAdapter extends RecyclerView.Adapter<YourOrderDetailsItemAdapter.MyViewHolder>{
    private Context context;
    private ArrayList<ItemObject> list;
    private LayoutInflater layoutInflater;
    public YourOrderDetailsItemAdapter(Context context, ArrayList<ItemObject> list) {
        this.context = context;
        this.list = list;
        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view=layoutInflater.inflate(R.layout.content_oderdetails_card_view,parent,false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        ItemObject item=list.get(position);
        if (item.getCategory().equalsIgnoreCase("Veg")){
            holder.frame_main.setBackgroundResource(R.drawable.gradient_green_color);
            holder.order_delete.setBackgroundResource(R.drawable.gradient_green_color);
        }else  if (item.getCategory().equalsIgnoreCase("NonVeg")){
            holder.frame_main.setBackgroundResource(R.drawable.gradient_red_color);
            holder.order_delete.setBackgroundResource(R.drawable.gradient_red_color);
        }else  if (item.getCategory().equalsIgnoreCase("Dessert")){
            holder.frame_main.setBackgroundResource(R.drawable.gradient_blue_color);
            holder.order_delete.setBackgroundResource(R.drawable.gradient_blue_color);
        }
        holder.name_tv.setText(item.getItemName());
        float totalprice=Float.parseFloat(item.getPrice());
        int q=Integer.parseInt(item.getQuantity());
        holder.amount_tv.setText(""+totalprice*q);
        holder.price_tv.setText(item.getPrice());
        holder.quantity_tv.setText(item.getQuantity());


    }


    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView name_tv;
        private TextView price_tv;
        private TextView amount_tv;
        private TextView quantity_tv;
        private FrameLayout frame_main;
        private ImageButton order_delete;


        public MyViewHolder(View itemView) {
            super(itemView);
            name_tv = (TextView)itemView.findViewById(R.id.orderDetailsItemName);
            quantity_tv = (TextView)itemView.findViewById(R.id.orderDetailsQuantity);
            price_tv = (TextView)itemView.findViewById(R.id.orderDetailsPrice);
            amount_tv = (TextView)itemView.findViewById(R.id.orderDetailsAmount);
            frame_main = (FrameLayout) itemView.findViewById(R.id.frame_main);
            order_delete = (ImageButton) itemView.findViewById(R.id.delete_item_bt);

        }
    }
}
