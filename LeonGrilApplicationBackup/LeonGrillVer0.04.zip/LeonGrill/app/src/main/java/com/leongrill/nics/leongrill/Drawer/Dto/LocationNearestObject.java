package com.leongrill.nics.leongrill.Drawer.Dto;

import android.support.annotation.NonNull;

import java.util.Comparator;

/**
 * Created by Savithri on 26-06-2017.
 */

public class LocationNearestObject {
    private  String latitude;
    private  String longitude;
    private double distance;


    public LocationNearestObject(String latitude, String longitude, double distance)
    {
        this.latitude=latitude;
        this.longitude=longitude;
        this.distance=distance;
    }


    public  String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public  String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

 public static Comparator<LocationNearestObject> DistanceF= new Comparator<LocationNearestObject>() {
     @Override
     public int compare(LocationNearestObject o1, LocationNearestObject o2) {
         double dist=o1.getDistance();
         double dist1=o2.getDistance();
//         return (int)(dist-dist1);
         return Double.compare(dist,dist1);
     }
 };
   /* @Override
    public int compareTo(LocationNearestObject o) {
        int s=((LocationNearestObject)o).getDistance();
        return this.distance-s;
    }

    @Override
    public String toString()
    {
        return latitude+","+longitude+","+ distance;
    }*/
}
