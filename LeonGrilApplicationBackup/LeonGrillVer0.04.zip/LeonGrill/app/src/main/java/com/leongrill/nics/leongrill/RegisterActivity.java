package com.leongrill.nics.leongrill;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.leongrill.nics.leongrill.Drawer.MainActivity;
import com.leongrill.nics.leongrill.Menu.MenuActivity;
import com.leongrill.nics.leongrill.Menu.YourOrderDetailsActivity;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {
    Button register_skip;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        register_skip=(Button)findViewById(R.id.signUp_btn_skip);
        register_skip.setOnClickListener(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.signUp_btn_skip:
                onBackPressed();
                break;
            case R.id.signUp_btn_signUp:

                break;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                onBackPressed();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }


}
