package com.leongrill.nics.leongrill.Utils;

/**
 * Created by Savithri on 19-06-2017.
 */

public interface IFragmentCommunicator {
    public void fragmentCommunication();
//    public static void Position(int position);
}
