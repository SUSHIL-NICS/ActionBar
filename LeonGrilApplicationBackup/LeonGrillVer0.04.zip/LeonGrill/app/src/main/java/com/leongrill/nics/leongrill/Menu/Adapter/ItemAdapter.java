package com.leongrill.nics.leongrill.Menu.Adapter;


import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.leongrill.nics.leongrill.Menu.Dto.ItemObject;
import com.leongrill.nics.leongrill.Menu.Fragment.ItemFragment;
import com.leongrill.nics.leongrill.R;

import java.util.ArrayList;

/**
 * Created by Savithri on 20-06-2017.
 */

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.MyViewHolder> {

    private Context context;
    private ArrayList<ItemObject> items;
    private LayoutInflater layoutInflater;
    private boolean isTrue;

    public void selectAllFavouriteItem(boolean isTrue) {
        this.isTrue=isTrue;
        notifyDataSetChanged();
    }

    public ItemAdapter(Context context, ArrayList<ItemObject> items) {
        this.context = context;
        this.items = items;
        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = layoutInflater.inflate(R.layout.containt_veg_menu_fragment, parent, false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;

    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        ItemObject itemObject=items.get(position);


        if(itemObject.getCategory().equalsIgnoreCase("veg"))
        {
            holder.linearLayout_card_bottom.setBackgroundResource(R.drawable.gradient_green_color);
        }else if (itemObject.getCategory().equalsIgnoreCase("NonVeg")){
            holder.linearLayout_card_bottom.setBackgroundResource(R.drawable.gradient_red_color);
        }else if (itemObject.getCategory().equalsIgnoreCase("Dessert")) {
            holder.linearLayout_card_bottom.setBackgroundResource(R.drawable.gradient_blue_color);
        }

        holder.name_tv.setText(itemObject.getItemName());
        holder.price_tv.setText(itemObject.getPrice());
        holder.background_imv.setImageResource(itemObject.getImage());

        if(isTrue==true) {
            String isFavourite=itemObject.getFavorite();
            String isCategory=itemObject.getCategory();
            if (isFavourite!= null && isFavourite.equalsIgnoreCase("1") && isCategory.equalsIgnoreCase("Veg")) {
                holder.fav_img.setImageResource(R.drawable.ic_favourite_heartred);
            } else if (isFavourite != null && isFavourite.equalsIgnoreCase("1") && isCategory.equalsIgnoreCase("NonVeg")) {
                holder.fav_img.setImageResource(R.drawable.ic_favourite_heartred);
            } else if (isFavourite != null && isFavourite.equalsIgnoreCase("1") && isCategory.equalsIgnoreCase("Dessert")) {
                holder.fav_img.setImageResource(R.drawable.ic_favourite_heartred);
            }
        }
        else {
            holder.fav_img.setImageResource(R.drawable.ic_favourite_heartwhite);
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        public TextView name_tv;
        public TextView price_tv;
        public ImageView background_imv;
        public ImageButton addToCard_imb;
        public ImageButton fav_img;
        public LinearLayout linearLayout_card_bottom;
        public MyViewHolder(View view){
            super(view);
            name_tv = (TextView)view.findViewById(R.id.veg_name_textView);
            price_tv = (TextView)view.findViewById(R.id.veg_price_textView);
            background_imv = (ImageView) view.findViewById(R.id.veg_imageView);
            addToCard_imb = (ImageButton) view.findViewById(R.id.veg_add_to_card_imageButton);
            fav_img = (ImageButton) view.findViewById(R.id.add_favorite_imageButton);
            linearLayout_card_bottom = (LinearLayout) view.findViewById(R.id.linearLayout_card_bottom);
        }
    }
}
