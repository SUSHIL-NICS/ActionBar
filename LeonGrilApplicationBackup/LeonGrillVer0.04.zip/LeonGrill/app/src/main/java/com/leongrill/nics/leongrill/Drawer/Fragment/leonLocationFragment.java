package com.leongrill.nics.leongrill.Drawer.Fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.leongrill.nics.leongrill.Database.DatabaseHelper;
import com.leongrill.nics.leongrill.Drawer.Dto.LocationObject;
import com.leongrill.nics.leongrill.Drawer.FragmentCommunicator;
import com.leongrill.nics.leongrill.Drawer.MainActivity;
import com.leongrill.nics.leongrill.R;
import com.leongrill.nics.leongrill.Utils.IFragmentCommunicator;

import java.util.ArrayList;
import java.util.List;


public class leonLocationFragment extends Fragment {

    private Button findLeon_btn;
    private Fragment fragment;
    private FragmentManager fragmentManager;
    private List<LocationObject> list;
    private  DatabaseHelper helper;
    private RadioButton radioButton1;
    private RadioButton radioButton2;
    private RadioButton radioButton3;
    private RadioButton radioButton4;
    private RadioGroup radioGroup;
    LocationObject locationObject;
    Button button;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        CopyData data=null;

        helper=new DatabaseHelper(getActivity());
        final int itemcount=helper.getLocationItemCount();
        if (itemcount==0){
            data = new CopyData();
            data.execute();
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_leon_location, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
               if (event.getAction()==KeyEvent.ACTION_DOWN){
                   if(keyCode==KeyEvent.KEYCODE_BACK){
                       Intent intent=new Intent(getActivity(), MainActivity.class);
                       startActivity(intent);
                       return true;
                   }
               }
                return false;
            }
        });
    }



    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        radioButton1=(RadioButton)view.findViewById(R.id.location_radio_button_one);
        findLeon_btn=(Button)view.findViewById(R.id.findLeno_btn);
        radioButton2=(RadioButton)view.findViewById(R.id.location_radio_button_two);
        radioButton3=(RadioButton)view.findViewById(R.id.location_radio_button_three);
        radioButton4=(RadioButton)view.findViewById(R.id.location_radio_button_four);
        radioGroup=(RadioGroup)view.findViewById(R.id.leon_location_radio_group);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId==R.id.location_radio_button_one){
                    locationObject=helper.getLocationData("HSR");
                }else if (checkedId==R.id.location_radio_button_two){
                    locationObject=helper.getLocationData("JeevanBimaHAL");
                }else if (checkedId==R.id.location_radio_button_three){
                    locationObject=helper.getLocationData("JeevanBimaComplex");
                }else if (checkedId==R.id.location_radio_button_four){
                    locationObject=helper.getLocationData("IndraNagar");
                }
            }
        });

        findLeon_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int checkedId =radioGroup.getCheckedRadioButtonId();
                if (checkedId==R.id.location_radio_button_one){
                   /* Toast.makeText(getContext(),locationObject.getLatitude()+"   HSR----- "
                            +locationObject.getLongitude(),Toast.LENGTH_LONG).show();*/
                    sendData(locationObject.getLatitude(),locationObject.getLongitude());
                }else if (checkedId==R.id.location_radio_button_two){

                    sendData(locationObject.getLatitude(),locationObject.getLongitude());
                }else if (checkedId==R.id.location_radio_button_three){

                    sendData(locationObject.getLatitude(),locationObject.getLongitude());
                }else if (checkedId==R.id.location_radio_button_four){


                    sendData(locationObject.getLatitude(),locationObject.getLongitude());
                }
            }
        });

    }
    public  void sendData(String lat,String lng)
    {
        FragmentCommunicator communicator= (FragmentCommunicator) getActivity();
        communicator.fragmentCommunicationLocation(lat,lng);
    }
    private class CopyData  extends AsyncTask<String,Void,Void> {

        private ProgressDialog progressDialog;

        @Override
        protected Void doInBackground(String... params) {
            list = getLocation();
            for(LocationObject item:list)
                helper.insertLocation(item);
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //Showing progress dialog while sending email
            progressDialog = ProgressDialog.show(getContext(),"","Please wait...",false,false);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            //Dismissing the progress dialog
            progressDialog.dismiss();
        }
    }

    private List<LocationObject> getLocation() {
        ArrayList<LocationObject> mList=new ArrayList<>();

        //category veg item
        mList.add(new LocationObject("12.911761","77.643799","HSR"));

        mList.add(new LocationObject("12.969132","77.648869","JeevanBimaHAL"));

        mList.add(new LocationObject("12.966578","77.660794","JeevanBimaComplex"));

        mList.add(new LocationObject("12.979231","77.640627","IndraNagar"));
        return mList;
    }

}
