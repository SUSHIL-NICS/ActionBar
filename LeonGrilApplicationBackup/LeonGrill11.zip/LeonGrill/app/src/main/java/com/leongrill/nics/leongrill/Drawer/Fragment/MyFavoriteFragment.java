package com.leongrill.nics.leongrill.Drawer.Fragment;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.leongrill.nics.leongrill.Database.DatabaseHelper;
import com.leongrill.nics.leongrill.Drawer.Adapter.FavoriteItemAdapter;
import com.leongrill.nics.leongrill.Drawer.Dto.FavoriteItemObject;

import com.leongrill.nics.leongrill.Drawer.FragmentCommunicator;
import com.leongrill.nics.leongrill.Menu.Adapter.YourOrderDetailsItemAdapter;
import com.leongrill.nics.leongrill.Menu.Dto.ItemObject;
import com.leongrill.nics.leongrill.Menu.RecyclerItemClickListener;
import com.leongrill.nics.leongrill.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Subrat on 13-06-2017.
 */

public class MyFavoriteFragment extends Fragment {

    private RecyclerView recyclerView;
    private DatabaseHelper helper;
    private ArrayList<ItemObject> items;
    private LinearLayout cartLinear;
    private int positions;
    private AppCompatButton favorite_btn;
    private SharedPreferences sharedPreferences;
    FavoriteItemAdapter favoriteItemAdapter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_favorite,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView=(RecyclerView)view.findViewById(R.id.my_favorite_RecyclerView);
        helper=new DatabaseHelper(getContext());
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        cartLinear= (LinearLayout)view.findViewById(R.id.cart_liner);
        favorite_btn= (AppCompatButton)view.findViewById(R.id.favorite_bt);
        favorite_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentCommunicator communicator= (FragmentCommunicator) getActivity();
                communicator.fragmentCommunication();
            }
        });
        items=helper.getCartItemFavorite();
        if(items.size()==0){
            cartLinear.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.INVISIBLE);
        }
         recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
         favoriteItemAdapter=new FavoriteItemAdapter(getContext(),items);
         recyclerView.setAdapter(favoriteItemAdapter);
        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getContext(),
                new RecyclerItemClickListener.OnItemClickListener() {
                    int count=0;
                    @Override
                    public void onItemClick(View view, final int position) {
                        final ItemObject item=items.get(position);
                        positions=position;
                        ImageView delete=(ImageButton) view.findViewById(R.id.favorite_productDelete_button);
                        delete.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                helper.updateFavorite(item.getItemName(), "0");
                                items.remove(position);
                                favoriteItemAdapter.notifyDataSetChanged();
                                if(items.size()==0) {
                                    cartLinear.setVisibility(View.VISIBLE);
                                    recyclerView.setVisibility(View.INVISIBLE);
                                }
                            }
                        });

                    }
                }));
    }
    @Override
    public void onResume() {
        super.onResume();
        if(items.size()==0){
            cartLinear.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.INVISIBLE);
            //sendmail.setVisibility(View.INVISIBLE);

        }
    }
}
