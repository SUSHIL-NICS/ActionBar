package com.leongrill.nics.leongrill.Drawer.ViewHolder;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bignerdranch.expandablerecyclerview.ViewHolder.ParentViewHolder;
import com.leongrill.nics.leongrill.R;


/**
 * Created by NIC-BISWA on 05-06-2017.
 */
public class OfferFragmentParentViewholder extends ParentViewHolder {

    public TextView supplierDiscount;
    public TextView supplierName;
    public LinearLayout supplierImage;
    public OfferFragmentParentViewholder(View itemView) {
        super(itemView);
        supplierDiscount= (TextView) itemView.findViewById(R.id.supplier_discount);
        supplierName= (TextView) itemView.findViewById(R.id.supplier_name);
        supplierImage= (LinearLayout) itemView.findViewById(R.id.image_offer);
    }
}
