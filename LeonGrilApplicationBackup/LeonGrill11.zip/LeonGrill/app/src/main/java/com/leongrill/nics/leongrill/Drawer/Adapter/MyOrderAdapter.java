package com.leongrill.nics.leongrill.Drawer.Adapter;


import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.leongrill.nics.leongrill.Drawer.Dto.MyOrderItemObject;
import com.leongrill.nics.leongrill.R;

import java.util.List;
//import android.support.v7.widget.PopupMenu;

public class MyOrderAdapter extends RecyclerView.Adapter<MyOrderAdapter.MyViewHolder>{
    private List<MyOrderItemObject> list_item;
    private Context context;

    public MyOrderAdapter(List<MyOrderItemObject> list_item, Context context) {
        this.list_item = list_item;
        this.context = context;
    }

    // Called when RecyclerView needs a new RecyclerView.ViewHolder of the given type to represent an item.

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                          int viewType) {
        //create a layout
        View view = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.content_my_order_fragment, null);

        MyViewHolder myViewHolder = new MyViewHolder(view,context,list_item);
        return myViewHolder;
    }


    // Called by RecyclerView to display the data at the specified position.
    @Override
    public void onBindViewHolder(final MyViewHolder myViewHolder, final int position ) {
        final MyOrderItemObject myList = list_item.get(position);
        myViewHolder.store_name.setText((myList.getStore()));
        myViewHolder.product_name.setText(myList.getProduct());
        myViewHolder.quantity.setText(myList.getQuantity());
        myViewHolder.imageView.setImageResource(myList.getImage());

        myViewHolder.store_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                        Toast.makeText(context,myList.getStore(), Toast.LENGTH_LONG).show();

            }
        });

    }

    @Override
    public int getItemCount() {
        return list_item.size();
    }

    // initializes some private fields to be used by RecyclerView.
    public static class MyViewHolder extends RecyclerView.ViewHolder  {

        public TextView store_name;
        public  TextView product_name;
        public  TextView quantity;
        public ImageView imageView;

        private List<MyOrderItemObject> list_item;
       Context context1;

        public MyViewHolder(View itemLayoutView,Context context1,List<MyOrderItemObject> list_item) {
            super(itemLayoutView);
            this.list_item=list_item;
            this.context1=context1;


            store_name = (TextView) itemLayoutView.findViewById(R.id.my_order_order_no_tv);
            product_name=(TextView)itemLayoutView.findViewById(R.id.my_order_product_name_tv);
            quantity=(TextView)itemLayoutView.findViewById(R.id.my_order_delivery_date_tv);
imageView=(ImageView)itemLayoutView.findViewById(R.id.my_order_imageview);
        }
    }

   /* public void setFilter(ArrayList<ListItem> newlist)
    {
        list_item=new ArrayList<>();
        list_item.addAll(newlist);
        notifyDataSetChanged();

    }*/
    //Returns the total number of items in the data set hold by the adapter.
    }

