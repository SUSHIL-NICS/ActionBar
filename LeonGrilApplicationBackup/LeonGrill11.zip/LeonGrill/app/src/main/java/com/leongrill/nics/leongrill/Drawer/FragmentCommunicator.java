package com.leongrill.nics.leongrill.Drawer;

/**
 * Created by Savithri on 23-06-2017.
 */

public interface FragmentCommunicator {
    void fragmentCommunicationLocation(String latitude,String longitude);
    public void fragmentCommunication();
}