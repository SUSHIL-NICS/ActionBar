package com.leongrill.nics.leongrill.Drawer;

import android.view.View;

/**
 * Created by sushil on 04-07-2017.
 */
public interface ClickListener {
    public void OnClick(View view,int position);

}
