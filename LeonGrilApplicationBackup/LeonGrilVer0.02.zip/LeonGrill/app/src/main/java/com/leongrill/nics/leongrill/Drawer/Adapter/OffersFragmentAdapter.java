package com.leongrill.nics.leongrill.Drawer.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bignerdranch.expandablerecyclerview.Adapter.ExpandableRecyclerAdapter;
import com.bignerdranch.expandablerecyclerview.Model.ParentObject;
import com.leongrill.nics.leongrill.Drawer.Dto.OfferFragmentChild;
import com.leongrill.nics.leongrill.Drawer.Dto.OfferFragmentParent;
import com.leongrill.nics.leongrill.Drawer.ViewHolder.OfferFragmentChildViewholder;
import com.leongrill.nics.leongrill.Drawer.ViewHolder.OfferFragmentParentViewholder;

import com.leongrill.nics.leongrill.R;

import java.util.List;

/**
 * Created by NIC-BISWA on 05-06-2017.
 */
public class OffersFragmentAdapter extends ExpandableRecyclerAdapter<OfferFragmentParentViewholder,OfferFragmentChildViewholder> {

    LayoutInflater layoutInflater;
    public OffersFragmentAdapter(Context context, List<ParentObject> parentItemList) {
        super(context, parentItemList);
        layoutInflater=LayoutInflater.from(context);
    }

    @Override
    public OfferFragmentParentViewholder onCreateParentViewHolder(ViewGroup viewGroup) {
        View view=layoutInflater.inflate(R.layout.offers_fragment_card,viewGroup,false);
        return new OfferFragmentParentViewholder(view);
    }

    @Override
    public OfferFragmentChildViewholder onCreateChildViewHolder(ViewGroup viewGroup) {
        View view=layoutInflater.inflate(R.layout.offers_card_child,viewGroup,false);
        return new OfferFragmentChildViewholder(view);
    }

    @Override
    public void onBindParentViewHolder(OfferFragmentParentViewholder supplierParentViewholder, int i, Object o) {
        OfferFragmentParent t=(OfferFragmentParent)o;
        supplierParentViewholder.supplierDiscount.setText(t.getSupplierDiscount());
        supplierParentViewholder.supplierName.setText(t.getSupplier_name());
       // supplierParentViewholder.supplierImage.setBackgroundResource(t.getHeart());

    }

    @Override
    public void onBindChildViewHolder(OfferFragmentChildViewholder supplierChildViewholder, int i, Object o) {
        OfferFragmentChild child= (OfferFragmentChild) o;
supplierChildViewholder.option1.setText(child.getOption1());
    supplierChildViewholder.option2.setText(child.getOption2());

    }
    }
