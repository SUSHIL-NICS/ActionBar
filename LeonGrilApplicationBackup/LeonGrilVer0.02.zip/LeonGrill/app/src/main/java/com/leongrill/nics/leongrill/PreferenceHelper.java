package com.leongrill.nics.leongrill;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by sushil on 03-07-2017.
 */
public class PreferenceHelper {
    Context context;
    SharedPreferences sharedPreferences;
    public PreferenceHelper(Context context)
    {
        this.context=context;
        sharedPreferences=context.getSharedPreferences("leon",Context.MODE_PRIVATE);
    }

    public boolean SaveCountToSharedPreference(String keyName,int value){
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putInt(keyName,value);
        editor.commit();
        editor.apply();
        return true;
    }

    public int getCountFormSharedPreference(String keyName){

        return sharedPreferences.getInt(keyName,0);
    }

}
