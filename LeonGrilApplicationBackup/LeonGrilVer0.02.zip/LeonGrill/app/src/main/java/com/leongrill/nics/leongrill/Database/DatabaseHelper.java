package com.leongrill.nics.leongrill.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.leongrill.nics.leongrill.Drawer.Dto.LocationObject;

import com.leongrill.nics.leongrill.Drawer.Dto.OrderHistoryDto;
import com.leongrill.nics.leongrill.Menu.Dto.ItemObject;
import com.leongrill.nics.leongrill.Utils.UserDTO;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Savithri on 19-06-2017.
 */

public class DatabaseHelper  extends SQLiteOpenHelper {
    public final static String DATABASE_NAME = "leonGrillDb";
    public final static int DATBASE_VERSION = 2;
    public SQLiteDatabase database;
    public static final String USER_TABLE = "user";
    public static final String USER_ID = "_id";
    public static final String USER_NAME = "name";
    public static final String USER_MOBILE = "mobile";
    public static final String USER_EMAIL = "email";
    private final static String USER_QUERY = "create table " + USER_TABLE + "(" + USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + USER_NAME + " TEXT,"  + USER_MOBILE + " TEXT," + USER_EMAIL + " TEXT)";


    public static final String ORDER_HISTORY_TABLE = "history";
    public static final String ORDER_HISTORY_ID = "_id";
    public static final String ORDER_HISTORY_NAME = "name";
    public static final String ORDER_HISTORY_PRICE = "price";
    public static final String ORDER_HISTORY_QUANTITY = "quantity";
    public static final String ORDER_HISTORY_CATEGORY = "category";
    public static final String ORDER_HISTORY_DATE_TIME = "datetime";
    public static final String ORDER_HISTORY_IMAGE= "image";

    private final static String ORDER_HISTORY_QUERY = "create table " + ORDER_HISTORY_TABLE + "(" + ORDER_HISTORY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + ORDER_HISTORY_IMAGE + " blob not null,"
            + ORDER_HISTORY_NAME + " TEXT,"
            + ORDER_HISTORY_PRICE + " TEXT,"
            + ORDER_HISTORY_QUANTITY + " TEXT,"
            + ORDER_HISTORY_CATEGORY + " TEXT,"
            + ORDER_HISTORY_DATE_TIME + " TEXT)";


    public final static String CART_TABLE = "cart";
    public final static String CART_ID = "_id";
    public final static String CART_PRODUCT_PRICE = "price";
    public final static String CART_PRODUCT_ID = "p_id";
    public static final String CART_COLUMN_IMAGE = "image";
    public final static String CART_PRODUCT_CATEGORY = "category";
    public final static String CART_PRODUCT_NAME = "product_name";
    public final static String CART_PRODUCT_QUANTITY = "quantity";
    public final static String CART_PRODUCT_FAVORITE = "favorite";
    public final static String CART_PRODUCT_CARTCOLOR = "cartColor";
    public final static String CART_PRODUCT_FAVORITECARTCOLOR = "favoriteColor";
    private final static String CART_QUERY = "create table " + CART_TABLE + "(" + CART_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + CART_PRODUCT_ID + " TEXT," + CART_COLUMN_IMAGE + " blob not null,"
            + CART_PRODUCT_PRICE + " TEXT,"  + CART_PRODUCT_NAME + " TEXT,"
            + CART_PRODUCT_QUANTITY + " TEXT,"
            + CART_PRODUCT_CATEGORY + " TEXT,"
            + CART_PRODUCT_CARTCOLOR + " TEXT,"
            + CART_PRODUCT_FAVORITECARTCOLOR + " TEXT,"
            + CART_PRODUCT_FAVORITE + " TEXT)";

    public static final String COLUMN_ITEM_NAME = "item_name";
    public static final String COLUMN_ITEM_CATEGORY = "item_category";
    public static final String COLUMN_ID = "_id";
    public static final String ITEM_ID = "item_id";
    public static final String COLUMN_PRICE = "price";
    public static final String COLUMN_IMAGE = "image";
    public final static String NEW_TABLE = "product_item";
    private final static String QUERY = "create table " + NEW_TABLE + "(" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + ITEM_ID + " TEXT," + COLUMN_IMAGE + " blob not null," + COLUMN_ITEM_NAME + " TEXT,"
            + COLUMN_PRICE + " TEXT,"
            + COLUMN_ITEM_CATEGORY + " TEXT)";


    public static final String LOCATION_TABLE = "location";
    public static final String LOCATION_ID = "_id";
    public static final String LOCATION_LATITUDE = "latitude";
    public static final String LOCATION_LONGITUDE = "longitude";
    public static final String LOCATION_AREA= "area";
    private final static String LOCATION_QUERY = "create table " + LOCATION_TABLE + "(" + LOCATION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + LOCATION_LATITUDE + " TEXT,"  + LOCATION_LONGITUDE + " TEXT," + LOCATION_AREA + " TEXT)";




    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATBASE_VERSION);
    }

    @Override

    public void onCreate(SQLiteDatabase db) {
        db.execSQL(USER_QUERY);
        db.execSQL(CART_QUERY);
        db.execSQL(QUERY);
        db.execSQL(LOCATION_QUERY);
        db.execSQL(ORDER_HISTORY_QUERY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub

    }
    public void insertUser(UserDTO dto) {
        try {
            database = getReadableDatabase();
            ContentValues values = new ContentValues();
            values.put(USER_NAME, dto.getName());
            values.put(USER_EMAIL, dto.getEmail());
            values.put(USER_MOBILE, dto.getMobile());
            database.insert(USER_TABLE, null, values);
            close();
        }catch (Exception e){
            e.printStackTrace();
            close();
        }

    }
    public int fetchUserCount() {
        database = getReadableDatabase();
        Cursor cursor = database.rawQuery("select * from " + USER_TABLE, null);
        if (cursor != null) {
            return cursor.getCount();
        }
        close();
        return 0;
    }
    public UserDTO fetchUserDetails(){
        UserDTO userDTO=null;
        database = getReadableDatabase();
        Cursor cursor = database.rawQuery("select * from " + USER_TABLE, null);
        if (cursor != null) {
            if (cursor.getCount()!=0){
                cursor.moveToFirst();
                do{
                    String name=cursor.getString(cursor.getColumnIndex(USER_NAME));
                    String mobile=cursor.getString(cursor.getColumnIndex(USER_MOBILE));
                    String emial=cursor.getString(cursor.getColumnIndex(USER_EMAIL));
                    userDTO=new UserDTO(name,mobile,emial);
                }while (cursor.moveToNext());
            }
        }
        close();
        return userDTO;
    }
    public void updateUserDetails(UserDTO dto){
        database=getReadableDatabase();
        ContentValues values=new ContentValues();
        values.put(USER_NAME, dto.getName());
        values.put(USER_EMAIL, dto.getEmail());
        values.put(USER_MOBILE, dto.getMobile());
        database.update(USER_TABLE,values,null,null);
        close();
    }

    public void updateCart(String name,String quantity,String color){
        database=getReadableDatabase();
        ContentValues value=new ContentValues();
        value.put(CART_PRODUCT_QUANTITY, quantity);
        value.put(CART_PRODUCT_CARTCOLOR, color);
        database.update(CART_TABLE,value,CART_PRODUCT_NAME+" =?",new String[]{name});
        close();
    }

    public void addToCart(ItemObject data) {
        database = getWritableDatabase();
        ContentValues value = new ContentValues();
        value.put(CART_PRODUCT_ID, data.getId());
        value.put(CART_COLUMN_IMAGE, data.getImage());
        value.put(CART_PRODUCT_PRICE, data.getPrice());
        value.put(CART_PRODUCT_NAME, data.getItemName());
        if(data.getQuantity()!=null)
            value.put(CART_PRODUCT_QUANTITY, data.getQuantity());
        else
            value.put(CART_PRODUCT_QUANTITY, "0");
        if(data.getFavorite()!=null)
            value.put(CART_PRODUCT_FAVORITE, data.getFavorite());
        else
            value.put(CART_PRODUCT_FAVORITE, "0");

        if(data.getCartColor()!=null)
            value.put(CART_PRODUCT_CARTCOLOR, data.getCartColor());
        else
            value.put(CART_PRODUCT_CARTCOLOR, "");

        if(data.getFavoriteColor()!=null)
            value.put(CART_PRODUCT_FAVORITECARTCOLOR, data.getCartColor());
        else
            value.put(CART_PRODUCT_FAVORITECARTCOLOR,"");

        value.put(CART_PRODUCT_CATEGORY, data.getCategory());
        database.insert(CART_TABLE, null, value);
        close();
    }

    public ArrayList<ItemObject> getCartItem() {
        database = getReadableDatabase();
        ArrayList<ItemObject> itemList = new ArrayList<ItemObject>();
        Cursor c = database.rawQuery("select * from " + CART_TABLE, null);
        if (c.getCount() != 0) {
            c.moveToFirst();
            do {
                ItemObject d = new ItemObject();
                String quantity=c.getString(c.getColumnIndex(CART_PRODUCT_QUANTITY));
                d.setPrice(c.getString(c.getColumnIndex(CART_PRODUCT_PRICE)));
                d.setItemName(c.getString(c.getColumnIndex(CART_PRODUCT_NAME)));
                d.setQuantity(c.getString(c.getColumnIndex(CART_PRODUCT_QUANTITY)));
                d.setImage(c.getInt(c.getColumnIndex(CART_COLUMN_IMAGE)));
                d.setCartColor(c.getString(c.getColumnIndex(CART_PRODUCT_CARTCOLOR)));
                if(quantity!=null && !quantity.equalsIgnoreCase("0"))
                    itemList.add(d);
            } while (c.moveToNext());
        }
        close();
        return itemList;
    }

    public ArrayList<ItemObject> fetchFromCart(String data) {
        ArrayList<ItemObject> items = new ArrayList<>();
        database = getReadableDatabase();
        Cursor c = database.rawQuery("select * from " + CART_TABLE + " where " + CART_PRODUCT_CATEGORY + " =?", new String[]{data});
        if (c != null) {
            int count=c.getCount();
            if (count != 0) {
                c.moveToFirst();
                do {
                    ItemObject item = new ItemObject();
                    item.setItemName(c.getString(c.getColumnIndex(CART_PRODUCT_NAME)));
                    item.setPrice(c.getString(c.getColumnIndex(CART_PRODUCT_PRICE)));
                    item.setQuantity(c.getString(c.getColumnIndex(CART_PRODUCT_QUANTITY)));
                    item.setImage(c.getInt(c.getColumnIndex(CART_COLUMN_IMAGE)));
                    item.setCategory(c.getString(c.getColumnIndex(CART_PRODUCT_CATEGORY)));
                    item.setFavorite(c.getString(c.getColumnIndex(CART_PRODUCT_FAVORITE)));
                    items.add(item);
                } while (c.moveToNext());
            }
        }
        close();
        return items;
    }

    public void updateFavorite(String name, String favorite, String cartColor){
        database=getReadableDatabase();
        ContentValues value=new ContentValues();
        value.put(CART_PRODUCT_FAVORITE, favorite);
        value.put(CART_PRODUCT_FAVORITECARTCOLOR, cartColor);
        database.update(CART_TABLE,value,CART_PRODUCT_NAME+" =?",new String[]{name});
        close();
    }

    public ArrayList<ItemObject> getCartItemFavorite() {
        database = getReadableDatabase();
        ArrayList<ItemObject> itemList = new ArrayList<ItemObject>();
        Cursor c = database.rawQuery("select * from " + CART_TABLE, null);
        if (c.getCount() != 0) {
            c.moveToFirst();
            do {
                ItemObject d = new ItemObject();
                String favorite=c.getString(c.getColumnIndex(CART_PRODUCT_FAVORITE));
                d.setPrice(c.getString(c.getColumnIndex(CART_PRODUCT_PRICE)));
                d.setItemName(c.getString(c.getColumnIndex(CART_PRODUCT_NAME)));
                d.setFavoriteColor(c.getString(c.getColumnIndex(CART_PRODUCT_FAVORITECARTCOLOR)));
                d.setImage(c.getInt(c.getColumnIndex(CART_COLUMN_IMAGE)));
                if(favorite!=null && !favorite.equalsIgnoreCase("0"))
                    itemList.add(d);
            } while (c.moveToNext());
        }
        close();
        return itemList;
    }

    public int getItemCount(){
        database = getReadableDatabase();
        int count=0;
        Cursor c = database.rawQuery("select * from " + NEW_TABLE ,null);
        if (c != null)
            count=c.getCount();
        return count;
    }

    public void insertItems(List<ItemObject> items) {
        for (ItemObject item:items) {
            if(isRecordExist(item.getId().trim())) {
                ContentValues value = new ContentValues();
                value.put(ITEM_ID, item.getId());
                value.put(COLUMN_IMAGE, item.getImage());
                value.put(COLUMN_ITEM_NAME, item.getItemName());
                value.put(COLUMN_PRICE, item.getPrice());
                value.put(COLUMN_ITEM_CATEGORY, item.getCategory());
                database = getWritableDatabase();
                database.insert(NEW_TABLE, null, value);
            }
        }
        close();
    }

    public ArrayList<ItemObject> getData(String data) {
        ArrayList<ItemObject> items = new ArrayList<>();
        database = getReadableDatabase();
        Cursor c=null;
        if(data.equalsIgnoreCase("all")){
            c= database.rawQuery("select * from " + NEW_TABLE , null);
        }
        else {
            c = database.rawQuery("select * from " + NEW_TABLE + " where " + COLUMN_ITEM_CATEGORY + " =?", new String[]{data});
        }
        if (c != null) {
            if (c.getCount() != 0) {
                c.moveToFirst();
                do {
                    ItemObject item = new ItemObject();
                    item.setId(c.getString(c.getColumnIndex(ITEM_ID)));
                    item.setImage(c.getInt(c.getColumnIndex(COLUMN_IMAGE)));
                    item.setItemName(c.getString(c.getColumnIndex(COLUMN_ITEM_NAME)));
                    item.setPrice(c.getString(c.getColumnIndex(COLUMN_PRICE)));
                    item.setCategory(c.getString(c.getColumnIndex(COLUMN_ITEM_CATEGORY)));
                    items.add(item);
                } while (c.moveToNext());
            }
        }
        close();
        return items;
    }

    public boolean isRecordExist(String id){
        boolean value=true;
        database=getReadableDatabase();
        Cursor cursor=database.rawQuery("select * from "+NEW_TABLE+" where "+ITEM_ID+" =?",new String[]{id});
        if (cursor!=null){
            int count=cursor.getCount();
            if (count!=0)
                value=false;
        }
        close();
        return value;
    }

    public int getLocationItemCount() {

        database = getReadableDatabase();
        int count=0;
        Cursor c = database.rawQuery("select * from " + LOCATION_TABLE ,null);
        if (c != null)
            count=c.getCount();
        return count;

    }

    public void insertLocation(LocationObject item) {
        database = getWritableDatabase();
        ContentValues value = new ContentValues();
        value.put(LOCATION_LATITUDE, item.getLatitude());
        value.put(LOCATION_LONGITUDE, item.getLongitude());
        value.put(LOCATION_AREA, item.getArea());
        database.insert(LOCATION_TABLE, null, value);
        close();

    }

    public LocationObject getLocationData(String data) {
        LocationObject locationObject=null;
        database = getReadableDatabase();
        Cursor cursor=null;
        cursor = database.rawQuery("select * from " + LOCATION_TABLE + " where " + LOCATION_AREA + " =?", new String[]{data});
        if (cursor != null) {

            if (cursor.getCount()!=0){
                cursor.moveToFirst();
                do{
                    String lat=cursor.getString(cursor.getColumnIndex(LOCATION_LATITUDE));
                    String lan=cursor.getString(cursor.getColumnIndex(LOCATION_LONGITUDE));
                    String area=cursor.getString(cursor.getColumnIndex(LOCATION_AREA));
                    locationObject=new LocationObject(lat,lan,area);
                }while (cursor.moveToNext());
            }
        }
        close();
        return locationObject;
    }

    public String fetchFromCartItemQuantity(String itemName) {
        String quantit=null;
        database = getReadableDatabase();
        Cursor c = database.rawQuery("select * from " + CART_TABLE + " where " + CART_PRODUCT_NAME + " =?", new String[]{itemName});

        if (c != null) {
            int count=c.getCount();
            if (count!=0){
                c.moveToFirst();
                do {
                    String quantity=c.getString(c.getColumnIndex(CART_PRODUCT_QUANTITY));
                    quantit=quantity;
                } while (c.moveToNext());
            }
        }
        close();
    return quantit;
    }

    public void insertHistory(OrderHistoryDto ohd)
    {
        database=getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(ORDER_HISTORY_NAME,ohd.getName());
        contentValues.put(ORDER_HISTORY_PRICE,ohd.getPrice());
        contentValues.put(ORDER_HISTORY_QUANTITY,ohd.getQuantity());
        contentValues.put(ORDER_HISTORY_DATE_TIME,ohd.getDateTime());
        contentValues.put(ORDER_HISTORY_CATEGORY,ohd.getCategory());
        contentValues.put(ORDER_HISTORY_IMAGE,ohd.getImage());
        database.insert(ORDER_HISTORY_TABLE,null,contentValues);
        close();
    }

    public ArrayList<String> fetchFromOrderHistoryList() {
        database=getReadableDatabase();
        ArrayList<String> arrayList=new ArrayList<>();
        Cursor c=database.rawQuery("SELECT DISTINCT "+ORDER_HISTORY_DATE_TIME+" FROM "+ORDER_HISTORY_TABLE,null);
        if (c!=null&&c.getCount()!=0){
            c.moveToFirst();
            do{
                String s=c.getString(c.getColumnIndex(ORDER_HISTORY_DATE_TIME));
                arrayList.add(s);
            }while (c.moveToNext());
        }
        for (int i=0;i<arrayList.size();i++){
            String date=arrayList.get(i);
            Cursor cursor=database.rawQuery("select "+ORDER_HISTORY_NAME+" from "+ORDER_HISTORY_TABLE+
                    " where "+ORDER_HISTORY_DATE_TIME+" =?",new String[]{date});
            if (cursor!=null && cursor.getCount()!=0){
                cursor.moveToFirst();
                do {
                    String item = cursor.getString(cursor.getColumnIndex(ORDER_HISTORY_NAME));
                    arrayList.set(i, date + "( " + item + " )");
                }
                while (cursor.moveToNext());
            }
        }
        close();
        return arrayList;
    }

    public ArrayList<OrderHistoryDto> fetchFromOrderHistoryListData(String dateTime) {
        database=getReadableDatabase();
        ArrayList<OrderHistoryDto> items = new ArrayList<>();
        Cursor c = database.rawQuery("select * from " + ORDER_HISTORY_TABLE + " where " + ORDER_HISTORY_DATE_TIME + " =?",new String[]{dateTime});
        if (c != null) {
            if (c.getCount() != 0) {
                c.moveToFirst();
                do {
                    OrderHistoryDto item = new OrderHistoryDto();
//                    item.setId(c.getString(c.getColumnIndex(ITEM_ID)));
                    item.setImage(c.getInt(c.getColumnIndex(ORDER_HISTORY_IMAGE)));
                    item.setName(c.getString(c.getColumnIndex(ORDER_HISTORY_NAME)));
                    item.setCategory(c.getString(c.getColumnIndex(ORDER_HISTORY_CATEGORY)));
                    item.setPrice(c.getString(c.getColumnIndex(ORDER_HISTORY_PRICE)));
                    item.setQuantity(c.getString(c.getColumnIndex(ORDER_HISTORY_QUANTITY)));
                    items.add(item);
                } while(c.moveToNext());
            }
        }
        close();
        return items;
    }
}
