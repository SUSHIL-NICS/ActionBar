package com.leongrill.nics.leongrill.Drawer.Adapter;



import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.leongrill.nics.leongrill.Drawer.Dto.FavoriteItemObject;
import com.leongrill.nics.leongrill.Menu.Dto.ItemObject;
import com.leongrill.nics.leongrill.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Savithri on 12-06-2017.
 */

public class FavoriteItemAdapter extends RecyclerView.Adapter<FavoriteItemAdapter.MyViewHolder>{
    private Context context;
    private ArrayList<ItemObject> list;
    private LayoutInflater layoutInflater;
    public FavoriteItemAdapter(Context context, ArrayList<ItemObject> list) {
        this.context=context;
        this.list = list;
        layoutInflater = LayoutInflater.from(context);
    }



    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view =layoutInflater.inflate(R.layout.containt_my_favorite_fragment,parent,false);
        MyViewHolder myViewHolder =  new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        ItemObject favoriteItemObject=list.get(position);

        if (favoriteItemObject.getFavoriteColor().equalsIgnoreCase("0")){
            holder.linearLayout_main.setBackgroundResource(R.drawable.gradient_green_color);
        }else  if (favoriteItemObject.getFavoriteColor().equalsIgnoreCase("1")){
            holder.linearLayout_main.setBackgroundResource(R.drawable.gradient_red_color);
        }else  if (favoriteItemObject.getFavoriteColor().equalsIgnoreCase("2")){
            holder.linearLayout_main.setBackgroundResource(R.drawable.gradient_blue_color);
        }
        holder.background_imv.setImageResource(favoriteItemObject.getImage());
        holder.name_tv.setText(favoriteItemObject.getItemName());
        holder.price_tv.setText(favoriteItemObject.getPrice());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView name_tv;
        private TextView price_tv;
        private ImageView background_imv;
        private LinearLayout linearLayout_main;

        public MyViewHolder(View itemView) {
            super(itemView);
            name_tv = (TextView)itemView.findViewById(R.id.favorite_productName_textView);
            price_tv = (TextView)itemView.findViewById(R.id.favorite_productPrice_textView);
            background_imv = (ImageView) itemView.findViewById(R.id.favorite_productImage_imageView);
            linearLayout_main = (LinearLayout) itemView.findViewById(R.id.linearLayout_main);

        }
    }
}
