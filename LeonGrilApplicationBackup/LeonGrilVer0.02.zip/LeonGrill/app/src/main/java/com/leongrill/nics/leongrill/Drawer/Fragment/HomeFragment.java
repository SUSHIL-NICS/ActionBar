package com.leongrill.nics.leongrill.Drawer.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.leongrill.nics.leongrill.Menu.LetMeThink;
import com.leongrill.nics.leongrill.Menu.MenuActivity;
import com.leongrill.nics.leongrill.R;
import com.leongrill.nics.leongrill.Utils.AppLocationService;

/**
 * Created by Savithri on 13-06-2017.
 */

public class HomeFragment extends Fragment implements View.OnClickListener {
    private AppLocationService appLocationService;
    private Button letMeThink_btn;
    private LinearLayout bottom_llv;
    private Button continue_btn;
    private TextView auto_detect_location,getAuto_detect_city;
    private Button main_continue_btn;
    private double latitude;
    private double longitude;
    private String address;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

         /*Initialization of objects*/
        appLocationService=new AppLocationService(getContext());
        auto_detect_location= (TextView) view.findViewById(R.id.leon_main_auto_detect_location_tv);
        getAuto_detect_city= (TextView) view.findViewById(R.id.leon_main_auto_detect_location_city_tv);
        main_continue_btn= (Button) view.findViewById(R.id.main_continue_btn);
        bottom_llv= (LinearLayout) view.findViewById(R.id.bottom_llv);
        auto_detect_location.setVisibility(View.GONE);
        getAuto_detect_city.setVisibility(View.GONE);
         final String lati=getArguments().getString("latitude");
         final String longi=getArguments().getString("longitude");

        /*Initialization of variables*/

        letMeThink_btn = (Button) view.findViewById(R.id.main_let_me_think_btn);
        continue_btn = (Button)view.findViewById(R.id.main_continue_btn);
        letMeThink_btn.setOnClickListener(this);
        continue_btn.setOnClickListener(this);

         /*Animation block*/
        final ImageView im= (ImageView) view.findViewById(R.id.leon_main_place_logo);

        final Animation an= AnimationUtils.loadAnimation(getContext(),R.anim.move);
        an.setRepeatCount(0);
        final Animation an1= AnimationUtils.loadAnimation(getContext(),R.anim.abc_fade_out);

        im.startAnimation(an);
        an.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                im.startAnimation(an1);
               if(lati==null && longi==null){
                   appLocationService.getLocation();
                   if (appLocationService.canGetLocation == false) {
                       // Here you can ask the user to try again, using return; for that
                       Toast.makeText(getContext(), "Your location is not available, please try again.", Toast.LENGTH_SHORT).show();
                       return;
                       // Or you can continue without getting the location, remove the return; above and uncomment the line given below
                       // address = "Location not available";
                   } else {
                       // Getting location co-ordinates
                       latitude = appLocationService.getLatitude();
                       longitude = appLocationService.getLongitude();
                       address = appLocationService.getLocationAddress(latitude,longitude);
                       if (address.equalsIgnoreCase("errorString")){

                       }else {
                           auto_detect_location.setText(address);
                           getAuto_detect_city.setText("");
                       }

                   }
                   bottom_llv.setVisibility(View.VISIBLE);
                   auto_detect_location.setVisibility(View.VISIBLE);
                   getAuto_detect_city.setVisibility(View.VISIBLE);
               }else{
                   appLocationService.canGetLocation();
                   if (appLocationService.canGetLocation == false) {
                       Toast.makeText(getContext(), "Your location is not available, please try again.", Toast.LENGTH_SHORT).show();
                       return;
                   } else {
                       // Getting location co-ordinates
                       address = appLocationService.getLocationAddress(Double.parseDouble(lati),Double.parseDouble(longi));
                       auto_detect_location.setText(address);
                       getAuto_detect_city.setText("");
                       Toast.makeText(getContext(),lati+"  ,  "+longi,Toast.LENGTH_LONG).show();
                       bottom_llv.setVisibility(View.VISIBLE);
                       auto_detect_location.setVisibility(View.VISIBLE);
                       getAuto_detect_city.setVisibility(View.VISIBLE);
                   }

               }

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        /*Animation block*/
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.main_continue_btn:
                Intent continueIntent=new Intent(getActivity(),MenuActivity.class);
                startActivity(continueIntent);
                break;
            case R.id.main_let_me_think_btn:
                Intent Intent=new Intent(getActivity(),LetMeThink.class);
                startActivity(Intent);
                break;
        }
    }


    /*@Override
    public void fragmentCommunication(String data) {
        this.data=data;
    }*/
}
