package com.leongrill.nics.leongrill.Menu.Dto;

import java.io.Serializable;

/**
 * Created by Savithri on 12-06-2017.
 */

public class ItemObject implements Serializable {

    private String id;
    private String category;
    private String itemName;
    private float totalprice;
    private String quantity;
    private String favorite;
    private String price;
    private int image;
    private String cartColor;
    private String favoriteColor;
    public String getCartColor() {
        return cartColor;
    }
    public void setCartColor(String cartColor) {
        this.cartColor = cartColor;
    }

    public String getFavoriteColor() {
        return favoriteColor;
    }
    public void setFavoriteColor(String favoriteColor) {
        this.favoriteColor = favoriteColor;
    }


    public String getFavorite() {
        return favorite;
    }

    public void setFavorite(String favorite) {
        this.favorite = favorite;
    }

     public ItemObject(String id, int image, String itemName, String price, String category){
            this.image=image;
            this.itemName=itemName;
            this.price=price;
            this.id=id;
            this.category=category;
        }

    public ItemObject() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public float getTotalprice() {
        return totalprice;
    }

    public void setTotalprice(float totalprice) {
        this.totalprice = totalprice;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }



}
