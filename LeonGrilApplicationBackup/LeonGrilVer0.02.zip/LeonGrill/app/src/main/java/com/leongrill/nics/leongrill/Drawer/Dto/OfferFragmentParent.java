package com.leongrill.nics.leongrill.Drawer.Dto;


import com.bignerdranch.expandablerecyclerview.Model.ParentObject;

import java.util.List;
import java.util.UUID;

/**
 * Created by NIC-BISWA on 05-06-2017.
 */
public class OfferFragmentParent implements ParentObject {

    private List<Object> supplierChildrenList;
    private UUID _id;
    String supplierDiscount,supplier_name;

    public int getHeart() {
        return heart;
    }

    int heart;
    int img;

    public OfferFragmentParent(String supplierDiscount, String supplier_name, int heart, int img) {
        this.supplierDiscount = supplierDiscount;
        this.supplier_name = supplier_name;
        this.img = img;
        this.heart = heart;

        _id=UUID.randomUUID();
    }

    public UUID get_id() {
        return _id;
    }

    public void set_id(UUID _id) {
        this._id = _id;
    }

    public String getSupplierDiscount() {
        return supplierDiscount;
    }

    public void setSupplierDiscount(String supplierDiscount) {
        this.supplierDiscount = supplierDiscount;
    }

    public String getSupplier_name() {
        return supplier_name;
    }

    public void setSupplier_name(String supplier_name) {
        this.supplier_name = supplier_name;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    @Override
    public List<Object> getChildObjectList() {
        return supplierChildrenList;
    }

    @Override
    public void setChildObjectList(List<Object> list) {
        supplierChildrenList=list;
    }
}
